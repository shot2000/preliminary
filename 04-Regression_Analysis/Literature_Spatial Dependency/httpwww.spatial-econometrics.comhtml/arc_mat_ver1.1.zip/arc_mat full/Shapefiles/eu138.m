data on 138 per capita income levels for European Union regions
(see arc_histmapd3.m demo file)

see  Le Gallo, J., C. Ertur C., Baumont C. (2003) A Spatial
Econometric Analysis of Convergence across European Regions,
1980-1995 European Regional Growth, B. Fingleton, (ed.), Springer
Verlag, Advances in Spatial Science, 99-130.

and, Le Gallo J., and C. Ertur (2003) Exploratory spatial data
analysis of the distribution of regional per capita GDP in Europe,
1980-1995, Papers in Regional Science, 82(2):175-201.

col1 = ID
col2 = OBS
col3 = NAME
col4 = AREA
col5 = ECU80
col6 = ECU81
col7 = ECU82
col8 = ECU83
col9 = ECU84
col10 = ECU85
col11 = ECU86
col12 = ECU87
col13 = ECU88
col14 = ECU89
col15 = ECU90
col16 = ECU91
col17 = ECU92
col18 = ECU93
col19 = ECU94
col20 = ECU95
col21 = LECU80
col22 = LECU81
col23 = LECU82
col24 = LECU83
col25 = LECU84
col26 = LECU85
col27 = LECU86
col28 = LECU87
col29 = LECU88
col30 = LECU89
col31 = LECU90
col32 = LECU91
col33 = LECU92
col34 = LECU93
col35 = LECU94
col36 = LECU95
TX8095
