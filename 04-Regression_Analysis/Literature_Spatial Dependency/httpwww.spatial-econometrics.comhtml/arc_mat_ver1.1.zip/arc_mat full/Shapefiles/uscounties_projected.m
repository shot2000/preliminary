uscounties_projected.dbf an arc_view map projection
(see arc_histmapd9.m demo file)

BEA information on:

% col1 AREANAME
% col2 FIPS
% col3 LATITUDE
% col4 LONGITUDE
% col5 POP1990
% col6 1987_PCI
% col7 1988_PCI
% col8 1989_PCI
% col9 1990_PCI
% col10 1991_PCI
% col11 1992_PCI
% col12 1993_PCI
