%     dbffile_read : reads an arcview (or other) dbffile and returns a structure containing
%    dbffile_readd : An example of using dbf_read() cmex function
%        make_html : makes HTML verion of contents.m files for the Econometrics Toolbox
%         make_map : constucts a map using structure variable returned by read_shape()
%         map_demo : An example of using shape_read() and make_map()
%       shape_read : reads an arcview shapfile and returns a structure 
%      shape_readd : An example of using shape_read() 
