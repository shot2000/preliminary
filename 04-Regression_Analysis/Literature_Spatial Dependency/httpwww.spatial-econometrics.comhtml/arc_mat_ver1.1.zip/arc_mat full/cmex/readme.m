% readme 

to compile use:

mex shp_read.c shapelib.c

which creates shp_read.dll

mex dbf_read.c shapelib.c

which creates dbf_read.dll

