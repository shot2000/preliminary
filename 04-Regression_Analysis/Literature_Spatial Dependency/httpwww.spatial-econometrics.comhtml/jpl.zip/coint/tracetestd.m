clear;
clc;

load thedata.txt ascii;	%CHANGE THIS


x=thedata(:,1:3); %GDP, CONS, PUBLIC CONS
dm0=thedata(:,4);	%money growth
dum=thedata(:,5);	%dummy variable

disp('Mod 3, 0 lags');
tracestat=tracetest(x,3,0)'
disp(' ');
disp('Mod 3, 2 lags');
tracestat=tracetest(x,3,2)'
disp(' ');
disp('Mod 3, 5 lags');
tracestat=tracetest(x,3,5)'
disp(' ');
disp('Mod 4, 3 lags')
tracestat=tracetest(x,4,3)'
disp(' ');
disp('Mod 3, 2 lags, money growth exog.');
tracestat=tracetest(x,3,2,dm0)'
disp(' ');
disp('Mod 4, 3 lags, dummy variable included');
tracestat=tracetest(x,4,3,dum)'


