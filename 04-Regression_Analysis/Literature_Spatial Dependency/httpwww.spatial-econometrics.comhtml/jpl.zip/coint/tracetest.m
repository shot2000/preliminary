function [tracestat] = tracetest(x,Mod,nlag,g)
%Johansen's trace test for cointegration.
%Written by Martin W Johansson (date: Oct 12, 2001)
%				Dept. of Economics
%				University of Lund
%				email:martin.johansson@nek.lu.se
%				
%This function calculates the statistic for the trace test 
%The following input arguments are needed:
%
%    x = A T*k1 matrix with the data, T=#obs, k1=variables.
%  Mod = 1,2,3,4 or 5 depending on how you want the determinstic
%        components defined, see Johansen (1995)
%    1 = No det trends in levels, no intercepts in CI-eq.
%    2 = No det trends in levels, intercepts in CI-eq.
%    3 = Linear trends in levels, intercepts in CI-eq.
%    4 = Linear trends in levels, linear trend in CI-eq.
%    5 = Quadratic trends in levels, linear trend in CI-eq.
% nlag = Number of lags.
%    g = A T*k2 matrix with exogenous variabels (optional).
%
%Syntax:[tracestat] = tracetest(x,Mod,nlag,g)
%
%Reference: Johansen S (1995), 'Likelihood-based inference
%'in cointegrated vector autoregressive models', Oxford
%university press.
%           
%
k=cols(x);

%Mod 1
z0=diff(x); z1=nclag(x,1,1);  z2=nclag(z0,1,nlag);
z0=trimr(z0,nlag,0); z1=trimr(z1,nlag+1,0); z2=trimr(z2,nlag,0);
nobs=rows(z0); c=ones(nobs,1)'; trend=linspace(1,nobs,nobs);
invnobs=inv(nobs); z0=z0'; z1=z1'; z2=z2'; 

if nargin==4; g=trimr(g,nlag+1,0); end

if Mod==2; z1=[z1; c]; end
if Mod==3; z2=[z2; c]; end
if Mod==4; z1=[z1; trend]; z2=[z2; c]; end
if Mod==5; z2=[z2; c; trend]; end
if nargin==4; z2=[z2;g']; end


M00=invnobs*z0*z0'; M01=invnobs*z0*z1'; M02=invnobs*z0*z2';
M11=invnobs*z1*z1'; M12=invnobs*z1*z2'; M22=invnobs*z2*z2';
R0=z0-M02*inv(M22)*z2; R1=z1-M12*inv(M22)*z2;

S00=invnobs*R0*R0';S01=invnobs*R0*R1'; 
S10=S01'; S11=invnobs*R1*R1';
SA=(inv(S11)*S10*inv(S00)*S01); ka=cols(SA);

l=1+(eig(SA-eye(ka))); l=flipud(sort(l)); 
if Mod==2; l=l(1:rows(l)-1); end;
if Mod==4; l=l(1:rows(l)-1); end;
tracestat=sum(tril(ones(k)).*(repmat(-nobs*(log(1-l)), [1 k])))';


