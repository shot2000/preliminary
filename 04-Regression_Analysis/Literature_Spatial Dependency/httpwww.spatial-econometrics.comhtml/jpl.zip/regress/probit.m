function result = probit(y,x,maxit,tol,prt_flag)
% PURPOSE: computes Probit Regression
%---------------------------------------------------
% USAGE: results = probit(y,x,maxit,tol)
% where: y = dependent variable vector (nobs x 1)
%        x = independent variables matrix (nobs x nvar)
%    maxit = optional (default=100)
%      tol = optional convergence (default=1e-6)
%    pflag = flag for printing information on iterations
%            1 = print (default), 0 = noprint
%---------------------------------------------------
% RETURNS: a structure
%        result.meth   = 'probit'
%        result.beta   = bhat
%        result.tstat  = t-stats
%        result.yhat   = yhat
%        result.resid  = residuals
%        result.sige   = e'*e/n
%        result.r2mf   = McFadden pseudo-R^2
%        result.rsqr   = Estrella R^2
%        result.lratio = LR-ratio test against intercept model
%        result.lik    = unrestricted Likelihood
%        result.cnvg   = convergence criterion, max(max(-inv(H)*g))
%        result.iter   = # of iterations
%        result.nobs   = nobs
%        result.nvar   = nvars
%        result.zip    = # of 0's
%        result.one    = # of 1's
%        result.y      = y data vector
% --------------------------------------------------
% SEE ALSO: prt_reg(results), logit(), tobit()
%---------------------------------------------------
% References: Arturo Estrella (1998) 'A new measure of fit
% for equations with dichotmous dependent variable', JBES,
% Vol. 16, #2, April, 1998.

% written by:
% James P. LeSage, Dept of Economics
% University of Toledo
% 2801 W. Bancroft St,
% Toledo, OH 43606
% jlesage@spatial-econometrics.com

% speed improvements provided by:
% Kenneth P. Brevoort
% Economist
% Financial Structure Section
% Board of Governors of the Federal Reserve System
% Washington, DC  20551
% Email:  Kenneth.P.Brevoort@frb.gov

if (nargin < 2 | nargin > 5); error('Wrong # of arguments to probit'); end;

if nargin == 5
    pflag = prt_flag;
else
    pflag = 1;
end;

[t,k] = size(x);
[nobs,junk] = size(y);

if (t ~= nobs); error('Y and X matrix have different # of observations'); end;

chk = sum((y==1));
if (chk==nobs)
    error('Probit: y-vector contains all ones');
elseif (chk==0)
    error('Profit:  y-vector contains no ones');
end;

% Maximum likelihood probit estimation
result.meth = 'probit';
options = foptions;

% Use OLS values as a start
b = (x'*x)\x'*y;

if (nargin ==2)
    tol = 0.000001;
    maxit = 100;
elseif (nargin==3)
    tol = 0.000001;
end;

iter = 1;
crit = 1;
info.cnames = strvcat('iteration','log-likelihood','criterion');
info.fmt = strvcat('%10d','%16.8f','%16.8f');
while (iter <= maxit) & (crit > tol)
    pdf = norm_pdf(x*b);
    cdf = norm_cdf(x*b);
    
    cdf = max(cdf,(cdf<=0)*0.00001);
    cdf = min(cdf,1 - (cdf>=1)*0.00001);
    
    g = (y.*(pdf./cdf) - (1 - y).*(pdf./(1 - cdf)))*ones(1,k).*x;
    gs = sum(g,1)';
    
    q = 2*y - 1;
    xb = x*b;
    pdf = norm_pdf(q.*xb);
    cdf = norm_cdf(q.*xb);
    lambda = (q.*pdf)./cdf;
    
    c = lambda.*(lambda + xb);
    H = - ((c*ones(1,k)).*x)'*x;
    
    db = -H\gs;
    
    %stepsize determination
    s = 1;
    term1 = -inf;
    term2 = pr_like(b+s*db,y,x);
    while (term2 > term1)
        term1 = term2;
        s = s/2;
        term2 = pr_like(b+s*db,y,x);
    end;
    
    b = b + 2*s*db;
    crit = max(abs(db));
    iter = iter + 1;
    if pflag == 1
    mprint([iter,full(term1),full(crit)],info);
    end;
end;

if (iter>=maxit)
    fprintf(1,'probit:  no convergence in %d iterations \n',iter);
end;

% now compute regression results
covb = -H\eye(k);
stdb = sqrt(diag(covb));
result.tstat = full(b./stdb);

% fitted probabilities
result.yhat = full(norm_cdf(x*b));
result.resid = full(y - result.yhat);

result.sige = full((result.resid'*result.resid)/t);

% find ones
P = sum((y==1))/t;
like0 = t*(P*log(P) + (1-P)*log(1-P)); % restricted likelihood
like1 = pr_like(b,y,x);                % unrestricted likelihood

result.r2mf = full(1 - (abs(like1)/abs(like0))); % McFadden pseudo-R2

term0 = (2/t)*like0;
term1 = 1/(abs(like1/like0)^term0);
result.rsqr = full(1 - term1);  % Estrella R2

result.beta = full(b);
result.lratio = full(2*(like1-like0));  % LR-ration test against intercept model
result.lik = full(like1);  % unrestricted likelihood
result.nobs = full(nobs);
result.nvar = full(k);
result.zip = full((1 - P)*t);
result.one = full(P*t);
result.iter = full(iter);
result.convg = full(crit);  % convergence criterion
result.y = full(y);

