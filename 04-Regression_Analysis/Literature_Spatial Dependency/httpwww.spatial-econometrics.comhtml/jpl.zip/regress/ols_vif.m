function result=ols_vif(y,x);
%%
%% ols with VIF estimation.Adds VIF factors to ols structure. 
%%
result=ols(y,x);
VIF=[];
for i=1:size(x,2)
    ytmp=x(:,i);
    if var(x(:,i))>0 & var(ytmp)>0 % get an error if regressing on non-varying column
        regs=[x(:,1:i-1),x(:,i+1:end)];
        tmpRes=ols(ytmp,regs);
        VIF(i)=1/(1-tmpRes.rsqr);
    else
        VIF(i)=0;
    end
    
end
result.VIF=VIF';