function ols_all=ols_os(y,regs,xpos);
%%
%% accepts an extra argument to mark out which data to hold OS
%% fills in the complete dataset of y,yhat,resid values so one can view 
%% the regression results both IS and OS
%%
notxpos=[1:size(y,1)];
notxpos=setdiff(notxpos,xpos);
ols_all=ols(y(notxpos),regs(notxpos,:));
betas=ols_all.beta;
ols_all.yhat=regs(:,:)*betas;
ols_all.resid=ols_all.yhat-y;
ols_all.y=y;
ols_all.outsamp=xpos;

