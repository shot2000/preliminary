% PURPOSE: demo of probit
%       with a large sample
%---------------------------------------------------
% USAGE: probit_d2
%---------------------------------------------------

clear all;

n=10000;
k = 3;
evec = randn(n,1);
tt=1:n;

x = randn(n,k);
x(1:n,1) = ones(n,1);

b = ones(k,1);
b(3,1) = -2.0;
b(2,1) = 2.0;
b(1,1) = -0.5;

y = x*b + evec;
yc = zeros(n,1);
% now censor the data
for i=1:n
 if y(i,1) > 0
 yc(i,1) = 1;
 else
 yc(i,1) = 0;
 end;
end;


Vnames = strvcat('y','constant','x1','x2');


result = probit(yc,x);
prt(result,Vnames);

tt=1:n;
[ys yi] = sort(result.y);
plot(tt,ys,tt,result.yhat(yi,1),'.');

