% PURPOSE: An example using ols(),
%                           prt(),
%                           plt(),
% ordinary least-squares estimation
%---------------------------------------------------
% USAGE: ols_d
%---------------------------------------------------

nobs = 1000;
nvar = 15;
beta = ones(nvar,1);

xmat = randn(nobs,nvar-1);

x = [ones(nobs,1) xmat];
evec = randn(nobs,1);

y = x*beta + evec;

vnames = strvcat('y-vector','constant','x1',';x2','x3','x4','x5','x6', ...
                 'x7','x8','x9','x10','x11','x12','x13','x14');

% do ols regression
result = ols_vif(y,x); 

% print the output
prt(result,vnames);

