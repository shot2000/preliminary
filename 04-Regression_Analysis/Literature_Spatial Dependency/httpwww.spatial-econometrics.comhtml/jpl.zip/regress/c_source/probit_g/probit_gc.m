function results = probit_g(y,x,ndraw,nomit,prior)
% PURPOSE: MCMC estimates for the Bayesian heteroscedastic probit model
%          y = X B + E, E = N(0,sige*V), 
%          V = diag(v1,v2,...vn), r/vi = ID chi(r)/r, r = Gamma(m,k)
%          B = N(c,T),     
%---------------------------------------------------
% USAGE: results = probit_g(y,x,ndraw,nomit,prior)
% where: y    = nx1 vector of 0,1 dependent variable values
%        x    = independent variables matrix of rank(k)
%       ndraw = # of draws
%       nomit = # of initial draws omitted for burn-in
%       prior = a structure for prior information input
%       prior.beta, prior means for beta,   c above (default diffuse)
%       priov.bcov, prior beta covariance , T above (default diffuse)
%       prior.rval, r prior hyperparameter, default=4
%       prior.m,    informative Gamma(m,k) prior on r
%       prior.k,    informative Gamma(m,k) prior on r
%       prior.dflag = 0 for return of only nomit+1:ndraw draws (default)
%                   = 1 for return of all 1:ndraw draws
%       prior.seed  = a numerical value to seed the random number generator
%                      (default is to use the system clock which produces
%                      different results on every run)
% ---------------------------------------------------
% RETURNS: a structure:
%          results.meth  = 'probit_g'
%          results.bdraw = bhat draws (ndraw-nomit x nvar)
%          results.vmean = mean of vi draws (nobs x 1)
%          results.yhat  = mean of latent z-draws
%          results.yprob = posterior probabilities for y = 0,1
%          results.rdraw = r-value draws (ndraw-nomit x 1), if Gamma(m,k) prior 
%          results.pmean = b prior means (prior.beta from input)
%          results.pstd  = b prior std deviation, sqrt(prior.bcov)
%          results.m     = prior m-value for r hyperparameter (if input)
%          results.k     = prior k-value for r hyperparameter (if input)
%          results.r     = value of hyperparameter r (if input)
%          results.r2mf  = McFadden R-squared
%          results.rsqr  = Estrella R-squared
%          results.nu    = prior nu-value for sige prior
%          results.d0    = prior d0-value for sige prior
%          results.nobs  = # of observations
%          results.nvar  = # of variables
%          results.ndraw = # of draws
%          results.nomit = # of initial draws omitted
%          results.y     = actual observations
%          results.x     = x-matrix
%          results.time  = time taken for sampling
%          results.pflag = 'plevel' (default) 
%                          or 'tstat' for bogus t-statistics
%          results.seed  = seed (if input, or zero if not)
% --------------------------------------------------
% NOTE: use either improper prior.rval 
%       or informative Gamma prior.m, prior.k, not both of them
%---------------------------------------------------
% SEE ALSO: coda, gmoment, prt_gibbs(results)
%---------------------------------------------------
% References: James H. Albert and Siddhartha Chib
%             Bayesian Analysis of Binary and Polychotomous
%             Response Data JASA, June 1993, pp. 669            
%----------------------------------------------------------------

% written by:
% James P. LeSage, Dept of Economics
% University of Toledo
% 2801 W. Bancroft St,
% Toledo, OH 43606
% jlesage@spatial-econometrics.com



% set defaults
[n k] = size(x);  
yin = y;

% check for all 1's or all 0's
tmp = find(y ==1);
chk = length(tmp); 
[nobs junk] = size(y);
if chk == nobs
   error('probit_g: y-vector contains all ones');
elseif chk == 0
   error('probit_g: y-vector contains no ones');
end;

seedflag = 0;
seed = 0;
dflag = 0;
mm = 0;  
kk= 0;
rval = 4;
nu = 0; 
d0 = 0; % default to a diffuse prior on sige
c = zeros(k,1); 
T = eye(k)*1e+12;

if  nargin == 5  % prior information
   if ~isstruct(prior)
    error('probit_g: must supply the prior as a structure variable');
   end;
fields = fieldnames(prior);
nf = length(fields);
 for i=1:nf
    if strcmp(fields{i},'rval')
        rval = prior.rval; 
    elseif strcmp(fields{i},'m')
        mm = prior.m;
        kk = prior.k;
        rval = gamm_rnd(1,1,mm,kk);    % initial value for rval
    elseif strcmp(fields{i},'nu')
        nu = prior.nu;
    elseif strcmp(fields{i},'d0')
        d0 = prior.d0;   
    elseif strcmp(fields{i},'beta');
    c = prior.beta;
    elseif strcmp(fields{i},'bcov');
       T = prior.bcov;
	elseif strcmp(fields{i},'dflag');
       dflag = prior.dflag;
    elseif strcmp(fields{i},'seed');
    seed = prior.seed;
    seedflag = 1;
    end;
 end;
elseif nargin == 4 
% use defaults

else
error('Wrong # of arguments to probit_g');
end;


[checkk,junk] = size(c);
if checkk ~= k
error('probit_g: prior means are wrong');
elseif junk ~= 1
error('ols_g: prior means are wrong');
end;

[checkk junk] = size(T);
if checkk ~= k
error('probit_g: prior bcov is wrong');
elseif junk ~= k
error('probit_g: prior bcov is wrong');
end;


TI = inv(T); 
TIc = TI*c;

if seedflag ~= 0;
rseed = num2str(seed);
end;

% sort the data into 0,1 vector
[ysort index] = sort(y);
xsort = x(index,:);
nzip = length(find(ysort == 0));

% =====================================================
% The sampler starts here
% =====================================================
time3 = clock; % start timing the sampler

fprintf(' -- MCMC sampling -- \n');
if seedflag == 0
    % [bdraw,yhat,vmean,rdraw,ymean] = 
    % probit_gc(y,x,rval,ndraw,nomit,nu,d0,mm,kk,TI,TIc,seed)
[bout,yhat,vmean,rout,ymean] = probit_gcc(ysort,xsort,rval,ndraw,nomit,mm,kk,TI,TIc);
else
[bout,yhat,vmean,rout,ymean] = probit_gcc(ysort,xsort,rval,ndraw,nomit,mm,kk,TI,TIc,rseed);
end;

if dflag == 0
    bout = bout(nomit+1:ndraw,:);
    rout = rout(nomit+1:ndraw,1);
end;

% compute cdf
yprob = stdn_cdf(yhat);

% unsort things
vmean = unsort(vmean,index);
yhat = unsort(ymean,index);
yprob = unsort(yprob,index);

time3 = etime(clock,time3);

bmean = mean(bout)';

% compute McFadden R-squared
tmp = find(yin ==1); % find ones
P = length(tmp); 
cnt0 = n-P;
cnt1 = P;
P = P/n; % proportion of 1's
like0 = n*(P*log(P) + (1-P)*log(1-P));    % restricted likelihood
like1 = pr_like(bmean,yin,x);            % unrestricted Likelihood
r2mf = 1-(abs(like1)/abs(like0));         % McFadden pseudo-R2 
% compute Estrella R-squared
term0 = (2/n)*like0;
term1 = 1/(abs(like1)/abs(like0))^term0;
rsqr = 1-term1;                           % Estrella R2



% return results
results.meth  = 'probit_g';
results.r2mf = r2mf;
results.rsqr = rsqr;
results.bdraw = bout;
results.pmean = c;
results.pstd  = sqrt(diag(T));
results.vmean = vmean;
results.yhat = yhat;
results.yprob = yprob;
if mm~= 0
results.rdraw = rout;
results.m     = mm;
results.k     = kk;
else
results.r     = rval;
results.rdraw = rout;
end;
results.nobs  = n;
results.nvar  = k;
results.y     = yin;
results.x     = x;
results.nu    = nu;
results.d0    = d0;
results.time = time3;
results.ndraw = ndraw;
results.nomit = nomit;
results.pflag = 'plevel';
results.seed = seed;
results.dflag = dflag;
