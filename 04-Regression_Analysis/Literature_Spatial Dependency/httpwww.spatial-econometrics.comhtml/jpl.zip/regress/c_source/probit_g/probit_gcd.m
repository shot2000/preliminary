% PURPOSE: demo of probit_g
%       Gibbs sampling for probit heteroscedastic estimation
%---------------------------------------------------
% USAGE: probit_gd
%---------------------------------------------------

clear all;
randn('seed',10201020);
n=300;
k = 3;
evec = randn(n,1);
tt=1:n;

x = randn(n,k);
x(1:n,1) = ones(n,1);

b = ones(k,1);
b(3,1) = -2.0;
b(2,1) = 2.0;
b(1,1) = 0.5;

y = 2*x*b + evec;
yc = zeros(n,1);
% now censor the data
for i=1:n
 if y(i,1) > 0
 yc(i,1) = 1;
 else
 yc(i,1) = 0;
 end;
end;

% add outliers
% x(50,2) = 5;
% x(75,3) = 5;

Vnames = strvcat('y','constant','x1','x2');

res2 = probit(yc,x);

prior.rval = 40;     % heteroscedastic prior
ndraw = 10000;
nomit = 1000;

result = probit_gc(yc,x,ndraw,nomit,prior);

prt(res2,Vnames);
prt(result,Vnames);


prior.seed = 20102010;
result2 = probit_gc(yc,x,ndraw,nomit,prior);
prt(result2,Vnames);

tt=1:n;
[ys yi] = sort(result.y);
plot(tt,ys,'o',tt,result.yprob(yi,1),'+');

% demo matlab function
result3 = probit_g(yc,x,ndraw,nomit,prior);
prt(result3,Vnames);
