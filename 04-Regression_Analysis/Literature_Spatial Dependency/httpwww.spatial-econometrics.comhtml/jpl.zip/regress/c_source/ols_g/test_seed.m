% PURPOSE: demo of ols_g() 
%          Gibbs sampling for Bayesian Heteroscedastic 
%          Linear Model
% 
%---------------------------------------------------
% USAGE: ols_gd
%---------------------------------------------------
clear all;
load yx.data;
y = yx(:,1);
x = yx(:,2:end);
[n k] = size(x);

% bmean = zeros(k,1);    % diffuse prior b means
%T = eye(k)*1000;       % diffuse prior b variance 
rval = 40;             % homoscedastic prior
%mm=8;                  % informative prior for r-value
%kk=2;  
%prior.beta = bmean;
%prior.bcov = T;
% prior.m = mm;         % use proper prior on r-value
% prior.k = kk;
prior.rval = rval;    % use improper prior on r-value

ndraw = 2000;
nomit = 1000;

seed = 654321;
prior.seed = seed;
result = ols_gc(y,x,ndraw,nomit,prior);
prt(result);

seed2 = 1654512;
prior.seed = seed;
result2 = ols_gc(y,x,ndraw,nomit,prior);
prt(result2);

