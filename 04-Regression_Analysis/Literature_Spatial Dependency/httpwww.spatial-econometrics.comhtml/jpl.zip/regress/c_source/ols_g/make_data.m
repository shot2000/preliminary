% PURPOSE: Make a least-squares data set and
%          write it to a file for re-use
% 
%---------------------------------------------------
% USAGE: make_data
%---------------------------------------------------
clear all;
n=100; k=3; % set number of observations and variables
sige = 10;
randn('seed',10201020);
x = randn(n,k); b = ones(k,1);   % generate data set
y = x*b + randn(n,1)*sqrt(sige); % homoscedastic model
in.fid = fopen('yx.data','w');
mprint([y x],in);
fclose(in.fid);


