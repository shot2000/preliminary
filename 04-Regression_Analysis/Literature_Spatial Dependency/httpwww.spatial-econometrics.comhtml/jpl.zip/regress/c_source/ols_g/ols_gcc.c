
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include <mex.h>
#include "randomlib.h"
#include "matrixjpl.h"

// *****************************************************
// mex ols_g file

// *****************************************************

// *****************************************************
// main sampler

// estimates robust 1st-order spatial autoregressive model using MCMC

// ols_gc(y,x,n,k,rval,ndraw,nomit,nu,d0,mm,kk,bdraw,sdraw,rdraw,vmean,TI,TIc);

void ols_gcc(
            double *y,     // y = nx1 lhs vector
			double *x,     // x = nxk explanatory variables matrix
            int n,         // n = # of observations
			int k,         // k = # of explanatory variables
            double rval,   // rval = hyperparameter r
            int ndraw,     // ndraw = # of draws
            int nomit,     // nomit = # of burn-in draws to omit
            double nu,     // nu = gamma prior for sige
            double d0,     // d0 = gamma prior for sige
            double mm,     // mm = exp prior for rval
            double kk,     // kk = exp prior for rval
            double *bdraw, // bout = draws for beta (ndraw,k) matrix
            double *sdraw, // sout = draws for sige (ndraw,1) vector
            double *rdraw, // rout = draws for rval if mm .ne. 0
            double *vmean, // vmean = mean of vi draws (n,1) vector
			double *TI,    // prior var-cov for beta (inverted in matlab)
			double *TIc)   // prior var-cov * prior mean

{
    // local stuff
    int i, j, iter, pflag, xccept, cnt;
    double *ys, **xs, **xt, **xmat, **xpx, *xpy, *v;
	double **priorv, *priorm;
	double *bhat, *bnorm, *parm, **covm, *work, *xb;
    double epe, chisq;
    double sige, vsqrt, dof, evec, chiv;
	BOOL invt;
	   
    // allocate vectors   
	xt   = dmatrix(0,k-1,0,n-1);
	xs   = dmatrix(0,n-1,0,k-1);
	xpx  = dmatrix(0,k-1,0,k-1);
	covm = dmatrix(0,k-1,0,k-1);
	xmat = dmatrix(0,n-1,0,k-1);
	priorv = dmatrix(0,k-1,0,k-1);
	
	ys   = dvector(0,n-1);
    v    = dvector(0,n-1);
	xpy  = dvector(0,k-1);
	priorm = dvector(0,k-1);
	bhat   = dvector(0,k-1);
	bnorm  = dvector(0,k-1);
	xb     = dvector(0,n-1);

	// put x into xmat
	// #define X(i,j) x[i + j*n]

	for(i=0; i<n; i++){
		v[i] = 1.0;
		for(j=0; j<k; j++)
			xmat[i][j] = x[i + j*n];
	}

    // put TI, TIc prior info into priorm, priorv
	for(i=0; i<k; i++){
		priorm[i] = TIc[i];
	    for(j=0; j<k; j++)
			priorv[i][j] = TI[i + j*k];
	}
    
// initializations
    dof = ((double) n + nu);    
    sige = 1.0;	
    evec = 0.0;

// do MCMC draws on sige, V, beta

// ======================================
// start the sampler
// ======================================

for(iter=0; iter<ndraw; iter++){

// apply variance scalars using matmulc
	for(i=0; i<n; i++){
		vsqrt = 1.0/sqrt(v[i]);
		ys[i] = y[i]*vsqrt;
		for(j=0; j<k; j++)
		xs[i][j] = xmat[i][j]*vsqrt;
	}

// ==================================================
// update beta with a multivariate normal draw
	transpose(xs,n,k,xt);
   
    matmat(xt, k, n, xs, k, xpx);

	matvec(xt, k, n, ys, xpy);

// add prior information
	for(i=0; i<k; i++){
		xpy[i] = xpy[i] + sige*priorm[i];
		for(j=0; j<k; j++)
			xpx[i][j] = xpx[i][j] + sige*priorv[i][j];
	}

// invert xpx
     invt = inverse(xpx, k);
	 if (invt != 1)
		 mexPrintf("ols_g: Inversion error in beta conditional \n");

// find bhat
	 matvec(xpx, k, k, xpy, bhat);

// multiply xpx-inverse times sige
     for(i=0; i<k; i++){
     for(j=0; j<k; j++)
     covm[i][j] = xpx[i][j]*sige;
     }
     
 // do multivariate normal draw based on sige*xpx-inverse
	 normal_rndc(covm, k, bnorm);

	for(i=0; i<k; i++)
		bhat[i] = bhat[i] + bnorm[i];

// ==================================================
// update sigma with a chi-squared draw

	// form xs*bhat
	matvec(xs, n, k, bhat, xb);

    epe = 0.0;
	for(i=0; i<n; i++){
		evec = ys[i] - xb[i];
		epe = epe + evec*evec;
	}
	chisq = genchi(dof);
    sige = (d0 + epe)/chisq;
        
// ==================================================
// update vi with a chi-squared draw

	// form x*bhat
	matvec(xmat, n, k, bhat, xb);

	for(i=0; i<n; i++){
    evec = y[i] - xb[i];
	chiv = genchi(rval+1.0);
	v[i] = ((evec*evec/sige) + rval)/chiv;
	}

//==================================================
// update rval if mm .ne. 0
    if (mm != 0.0){
    rval = gengam(mm,kk);
    }
    
// ==================================================
// save the draws
   *(sdraw+iter) = sige;
   
// #define X(i,j) x[i + j*n]
   for(j=0; j<k; j++)
   bdraw[iter + j*ndraw] = bhat[j];
   
   *(rdraw+iter) = rval;
   if (iter > nomit){
		for(i=0; i<n; i++)
        vmean[i] = vmean[i] + v[i]/((double) (ndraw-nomit));
        }
        
}
// ======================================
// end of the sampler
// ======================================


// free up allocated vectors

	free_dmatrix(xt,0,k-1,0);
	free_dmatrix(xs,0,n-1,0);
	free_dmatrix(xpx,0,k-1,0);
	free_dvector(xpy,0);
	free_dmatrix(xmat,0,n-1,0);
	free_dmatrix(priorv,0,k-1,0);
	free_dmatrix(covm,0,k-1,0);

    free_dvector(ys,0);
    free_dvector(v,0);
	free_dvector(bhat,0);
	free_dvector(bnorm,0);
	free_dvector(priorm,0);
	free_dvector(xb,0);



} // end of ols_gc



void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  double *y, *x, *bdraw, *sdraw, *rdraw, *vmean;
  int  i, n, k, ndraw, nomit;
  double nu, d0, rval, mm, kk;
  double *TI, *TIc;

  int buflen, status, flag;
  char *phrase;
  static char phrase2[8];
  long *Seed1, *Seed2;

    phrase2[0] = 'h';
    phrase2[1] = 'h';
    phrase2[2] = 'i';
    phrase2[3] = 't';
    phrase2[4] = 'h';
    phrase2[5] = 'e';
    phrase2[6] = 'r';
    phrase2[7] = 'e';


  /* Check for proper number of arguments. */
  if(nrhs == 11) {
    flag = 0;
    phrase = phrase2;
  } else if (nrhs == 12){
    flag = 1;
  } else {
    mexErrMsgTxt("ols_gc: 11 or 12 inputs required.");
  }
  if(nlhs != 4) {
    mexErrMsgTxt("ols_gc: 4 output arguments needed");
  }

      if (flag == 1) {

    // input must be a string
    if ( mxIsChar(prhs[11]) != 1)
      mexErrMsgTxt("ols_gc: seed must be a string.");
    // input must be a row vector
    if (mxGetM(prhs[11])!=1)
      mexErrMsgTxt("ols_gc: seed input must be a row vector.");

    // get the length of the input string
    buflen = (mxGetM(prhs[11]) * mxGetN(prhs[11])) + 1;

    // allocate memory for input string
    phrase = mxCalloc(buflen, sizeof(char));

    // copy the string data from prhs[0] into a C string input_ buf.
    // If the string array contains several rows, they are copied,
    // one column at a time, into one long string array.
    //
    status = mxGetString(prhs[11], phrase, buflen);
    if(status != 0)
      mexWarnMsgTxt("ols_gc: Not enough space. seed string truncated.");
    }
    

    // allow the user to set a seed or rely on clock-based seed
   if (flag == 0) {
    setSeedTimeCore(phrase);
   } else {
	phrtsd(phrase,&Seed1,&Seed2);
    setall(Seed1,Seed2);
   }

  	//  parse input arguments
    // [bdraw,sdraw,vmean,rdraw] = 
    // ols_gc(y,x,rval,ndraw,nomit,nu,d0,mm,kk,TI,TIc,seed)

     y = mxGetPr(prhs[0]);
	 x  = mxGetPr(prhs[1]);
	 n = mxGetM(prhs[1]);
	 k = mxGetN(prhs[1]);
	 rval = mxGetScalar(prhs[2]);
	 ndraw = (int) mxGetScalar(prhs[3]);
	 nomit = (int) mxGetScalar(prhs[4]);
	 nu = mxGetScalar(prhs[5]);
	 d0 = mxGetScalar(prhs[6]);
	 mm = mxGetScalar(prhs[7]);
	 kk = mxGetScalar(prhs[8]);
	 TI = mxGetPr(prhs[9]);
	 TIc = mxGetPr(prhs[10]);
	 
	// no need for error checking on inputs
	// since this was done in the matlab function


    /* Create matrices for the return arguments */
	 //bdraw,sdraw,rdraw,vmean,cntr
	plhs[0] = mxCreateDoubleMatrix(ndraw,k, mxREAL); // beta draws
	plhs[1] = mxCreateDoubleMatrix(ndraw,1, mxREAL); // sige draws
	plhs[2] = mxCreateDoubleMatrix(n,1, mxREAL);     // vmean
	plhs[3] = mxCreateDoubleMatrix(ndraw,1, mxREAL);     // rdraw

	bdraw = mxGetPr(plhs[0]);
	sdraw = mxGetPr(plhs[1]);
	vmean = mxGetPr(plhs[2]);
	rdraw = mxGetPr(plhs[3]);


    /* Call the  subroutine. */
    ols_gcc(y,x,n,k,rval,ndraw,nomit,nu,d0,mm,kk,bdraw,sdraw,rdraw,vmean,TI,TIc);


}


