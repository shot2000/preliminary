function results = ols_gc(y,x,ndraw,nomit,prior)
% PURPOSE: MCMC estimates for the Bayesian heteroscedastic linear model
%          y = X B + E, E = N(0,sige*V), 
%          V = diag(v1,v2,...vn), r/vi = ID chi(r)/r, r = Gamma(m,k)
%          B = N(c,T),  sige = gamma(nu,d0)    
%---------------------------------------------------
% USAGE: results = ols_gc(y,x,ndraw,nomit,prior)
% where: y    = dependent variable vector
%        x    = independent variables matrix of rank(k)
%       ndraw = # of draws
%       nomit = # of initial draws omitted for burn-in
%       prior = a structure for prior information input
%       prior.beta, prior means for beta,   c above (default diffuse)
%       priov.bcov, prior beta covariance , T above (default diffuse)
%       prior.rval, r prior hyperparameter, default=4
%       prior.m,    informative Gamma(m,k) prior on r
%       prior.k,    informative Gamma(m,k) prior on r
%       prior.nu,   informative Gamma(nu,d0) prior on sige
%       prior.d0    informative Gamma(nu,d0) prior on sige
%                   default for above: nu=0,d0=0 (diffuse prior)
%       prior.dflag = 0 for return of only nomit+1:ndraw draws (default)
%                   = 1 for return of all 1:ndraw draws
%       prior.seed  = a numerical value to seed the random number generator
%                      (default is to use the system clock which produces
%                      different results on every run)
% ---------------------------------------------------
% RETURNS: a structure:
%          results.meth  = 'ols_gc'
%          results.bdraw = bhat draws (ndraw-nomit x nvar)
%          results.vmean = mean of vi draws (nobs x 1)
%          results.sdraw = sige draws (ndraw-nomit x 1)
%          results.yhat  = mean of draws from posterior for y-predicted
%          results.rdraw = r-value draws (ndraw-nomit x 1), if Gamma(m,k) prior 
%          results.pmean = b prior means (prior.beta from input)
%          results.pstd  = b prior std deviation, sqrt(prior.bcov)
%          results.m     = prior m-value for r hyperparameter (if input)
%          results.k     = prior k-value for r hyperparameter (if input)
%          results.r     = value of hyperparameter r (if input)
%          results.nu    = prior nu-value for sige prior
%          results.d0    = prior d0-value for sige prior
%          results.nobs  = # of observations
%          results.nvar  = # of variables
%          results.ndraw = # of draws
%          results.nomit = # of initial draws omitted
%          results.y     = actual observations
%          results.x     = x-matrix
%          results.time  = time taken for sampling
%          results.pflag = 'plevel' (default) 
%                          or 'tstat' for bogus t-statistics
%          results.seed  = seed (if input, or zero if not)
% --------------------------------------------------
% NOTE: use either improper prior.rval 
%       or informative Gamma prior.m, prior.k, not both of them
%---------------------------------------------------
% SEE ALSO: coda, gmoment, prt_gibbs(results)
%---------------------------------------------------
% REFERENCES: Geweke (1993)  'Bayesian Treatment of the 
% Independent Student-$t$ Linear Model', Journal of Applied
% Econometrics, 8, s19-s40.
% ----------------------------------------------------

% written by:
% James P. LeSage, Dept of Economics
% University of Toledo
% 2801 W. Bancroft St,
% Toledo, OH 43606
% jlesage@spatial-econometrics.com

% set defaults
[n k] = size(x);   
seedflag = 0;
seed = 0;
dflag = 0;
mm = 0;  
kk= 0;
rval = 4;
nu = 0; 
d0 = 0; % default to a diffuse prior on sige
c = zeros(k,1); 
T = eye(k)*1e+12;

if  nargin == 5  % prior information
   if ~isstruct(prior)
    error('ols_g: must supply the prior as a structure variable');
   end;
   % parse prior structure
fields = fieldnames(prior);
nf = length(fields);
 for i=1:nf
    if strcmp(fields{i},'rval')
        rval = prior.rval; 
    elseif strcmp(fields{i},'m')
        mm = prior.m;
        kk = prior.k;
        rval = gamm_rnd(1,1,mm,kk);    % initial value for rval
    elseif strcmp(fields{i},'nu')
        nu = prior.nu;
    elseif strcmp(fields{i},'d0')
        d0 = prior.d0;   
    elseif strcmp(fields{i},'beta');
    c = prior.beta;
    elseif strcmp(fields{i},'bcov');
       T = prior.bcov;
	elseif strcmp(fields{i},'dflag');
       dflag = prior.dflag;
    elseif strcmp(fields{i},'seed');
    seed = prior.seed;
    seedflag = 1;
    end;
 end;

elseif nargin == 4 % use defaults
    
else
error('Wrong # of arguments to ols_gc');
end;

[checkk,junk] = size(c);
if checkk ~= k
error('ols_gc: prior means are wrong');
elseif junk ~= 1
error('ols_gc: prior means are wrong');
end;

[checkk junk] = size(T);
if checkk ~= k
error('ols_gc: prior bcov is wrong');
elseif junk ~= k
error('ols_gc: prior bcov is wrong');
end;


TI = inv(T); 
TIc = TI*c;

if seedflag ~= 0;
rseed = num2str(seed);
end;

% =====================================================
% The sampler starts here
% =====================================================
time3 = clock; % start timing the sampler

fprintf(' -- ols_gc: MCMC sampling -- \n');
if seedflag == 0
    % [bdraw,sdraw,vmean,rdraw] = 
    % ols_gcc(y,x,rval,ndraw,nomit,nu,d0,mm,kk,TI,TIc,seed)

[bout,sout,vmean,rout] = ols_gcc(y,x,rval,ndraw,nomit,nu,d0,mm,kk,TI,TIc);
else
[bout,sout,vmean,rout] = ols_gcc(y,x,rval,ndraw,nomit,nu,d0,mm,kk,TI,TIc,rseed);

end;

if dflag == 0
    bout = bout(nomit+1:ndraw,:);
    sout = sout(nomit+1:ndraw,1);
    rout = rout(nomit+1:ndraw,1);
end;

time3 = etime(clock,time3);

bmean = mean(bout)';

yhat = x*bmean;

% return results
results.meth  = 'ols_gc';
results.bdraw = bout;
results.pmean = c;
results.pstd  = sqrt(diag(T));
results.vmean = vmean;
results.sdraw = sout;
results.yhat = yhat;
if mm~= 0
results.rdraw = rout;
results.m     = mm;
results.k     = kk;
else
results.r     = rval;
results.rdraw = rout;
end;
results.nobs  = n;
results.nvar  = k;
results.y     = y;
results.x     = x;
results.nu    = nu;
results.d0    = d0;
results.time = time3;
results.ndraw = ndraw;
results.nomit = nomit;
results.pflag = 'plevel';
results.seed = seed;
results.dflag = dflag;
