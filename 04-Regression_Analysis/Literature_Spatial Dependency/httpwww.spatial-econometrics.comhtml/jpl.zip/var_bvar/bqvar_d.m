clear all;
clc;
clf;

%This program demonstrates the use of BQVAR.
%It reads in data on relative log gdp (y), the log real
%exchange rate (q) and relative log prices (p)
%between US and Germany during 1973:3-1991:4.
%It then performs a decomposition of the system
%into three 'driving' shocks, AS, IS and LM.
%The decomposition is performed so that only
%AS shocks are allowed to have long-run effects
%on relative GDP. Only AS and IS shocks are allowed
%to have long-run effects on the real exchange rate.
%All shocks may leave long-run effects on relative prices.

%For a lengthy exposition see:
% Clarida & Gali (1994)
%'Sources of real exchange rate fluctuations: How 
% important are nominal shocks?'
% NBER WP#4658


load bqdata.dat;   
y=bqdata(:,1);					  %relative (log) gdp.
q=bqdata(:,2);					  %(log) real exchange rate.
p=bqdata(:,3);					  %relative (log) prices.

x=100*diff([y q p]); 	%percentage change in variables

%settings
p=4; 			%lag length, NOT prices any more
s=40;			%steps in IRFs & FEVDs
dtrend=1;	%just an intercept

result=bqvar(x,p,s,dtrend);

IRF_L=result.IRF_L;		%accumulated IRFs
FEVD_L=result.FEVD_L;	%accumulated FEVDs

%Graphing the results
%Plotting the responses of the variables
subplot(3,3,1); plot(IRF_L(:,1)); title('AS -> y');
subplot(3,3,2); plot(IRF_L(:,2)); title('IS -> y');
subplot(3,3,3); plot(IRF_L(:,3)); title('LM -> y');

subplot(3,3,4); plot(IRF_L(:,4)); title('AS -> q');
subplot(3,3,5); plot(IRF_L(:,5)); title('IS -> q');
subplot(3,3,6); plot(IRF_L(:,6)); title('LM -> q');

subplot(3,3,7); plot(IRF_L(:,7)); title('AS -> p');
subplot(3,3,8); plot(IRF_L(:,8)); title('IS -> p');
subplot(3,3,9); plot(IRF_L(:,9)); title('LM -> p');
pause;

%The FEVD of the real exchange rate
figure; A=FEVD_L(:,4:6); areahandle=area(A);
hold on;
title('FEVD of q wrt. AS, IS and LM shocks');
legend(areahandle,'AS','IS','LM');
hold off;
