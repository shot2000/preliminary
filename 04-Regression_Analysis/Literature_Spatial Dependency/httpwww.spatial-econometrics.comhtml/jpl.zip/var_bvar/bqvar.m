function result = BQVAR(x,p,s,dtrend)
% PURPOSE: Blanchard & Quah (1989) decompostion, unrestricted VAR , IRF and FEVD
% Usage: result = BQVAR(x,p,s,dtrend)
% -------------------------------------------------------
% Where: x = A T*k matrix with the data, T=#obs, k=variables.
%        p = Number of lags in unrestricted VAR.
%        s = number of steps in IRFs and FEVDs.
%   dtrend = 0,1,2 depending on how you want the determinstic
%            components defined, see below...
%        0 = No deterministic trends.
%        1 = Intercept. (default)
%        2 = Intercept and linear trend.
%-------------------------------------------------------
% RETURNS: a results structure:
%          result.IRF_D  = IRFs in first diff.
%          result.IRF_L  = IRFs in levels.
%          result.FEVD_D = FEVD in first diff.
%          result.FEVD_L = FEVD in levels.
%          result.u      = structural shocks.
%          result.e      = reduced form shocks. 
%-------------------------------------------------------
% NOTES: The function basically performs a LT Cholesky decompostion of the 
% long-run VMA matrix. Since the factorisation is LT this means that the only
% shock which may have long-run effects on the first variable is the first
% shock while the first and second shock may have long-run effects on the second
% variable. The first, second and third shock may have long-run effects on the 
% third variable etc, etc...
% The IRFs and FEVD are organised in 'variablewise'. Thus the first block of k 
% columns holds the IRFs/FEVDs of the first variable to shock 1...k. The next block
% of k columns holds the IRFs/FEVDs of the second variable to shock 1...k, etc, etc... 
% Finally the orthogonalized (reduced form) residuals are stored in result.u (result.e)
%-------------------------------------------------------
% Reference: Blanchard & Quah (1989), 'The dynamic effects of
% aggregate demand and supply disturbances', American Economic
% Review, 79:4, 654-673.           
%-------------------------------------------------------

% Written by Martin W Johansson (date: Oct 16, 2001)
%			Dept. of Economics
%			University of Lund
%			email:martin.johansson@nek.lu.se

if nargin==3; dtrend=1; end
k=cols(x); 

%Estimating unrestricted VAR(p).
xlag=[];
for i=1:p;
xlag=[xlag nclag(x,i,i)];
end
x=trimr(x,p,0); xlag=trimr(xlag,p,0); nobs=rows(xlag); 
intercept=ones(nobs,1); lintrend=linspace(1,nobs,nobs)';

if dtrend==1; xlag=[intercept xlag]; end
if dtrend==2; xlag=[intercept lintrend xlag]; end

b=xlag\x; bt=b'; ndf=nobs-rows(bt); 


if dtrend==1; bt=b(2:rows(b),:)'; end
if dtrend==2; bt=b(3:rows(b),:)'; end

e=x-xlag*b;					  	  
sigma=inv(ndf)*e'*e;	     %VCV according to Eviews 4 p507.

%Imposing long-run restrictions
S=chol(sigma)';			  
if p==1
   sumbt=bt;
   else
sumbt=reshape(vec(bt),k*k,p);
sumbt=sum(sumbt')'; sumbt=reshape(sumbt,k,k);
end
C1=inv(eye(k)-sumbt);		  
invC1=inv(C1);				     
G=chol(C1*sigma*C1')'; 
A=eye(k);						   
B=invC1*G;					     
u=((inv(B)*A)*e')';

%Calculating the IRFs
J=[eye(k) zeros(k,k*p-k)];
A=[bt;[eye((p-1)*k) zeros((p-1)*k,k)]];
imp_resp=[];

for i=0:s-1
   theta=J*A^i*J';
   imp_add=theta*B;
   imp_add=vec(imp_add')';
   imp_resp=[imp_resp; imp_add];
end

%Defining IRFs in levels and first diff
imp_resp_D=imp_resp;
imp_resp_L=cumsum(imp_resp);

%FEVD in differences
fevd_D=cumsum(imp_resp_D.^2); 
sum_fevd_D=repmat(fevd_D, [k 1]);
sum_fevd_D=sum((sum_fevd_D.*kron(eye(k),ones(s,k)))')';
sum_fevd_D=reshape(sum_fevd_D,s,k);
sum_fevd_D=kron(sum_fevd_D,ones(1,k));
w_D=100*fevd_D./sum_fevd_D;

%FEVD in levels
fevd_L=cumsum(imp_resp_L.^2); 
sum_fevd_L=repmat(fevd_L, [k 1]);
sum_fevd_L=sum((sum_fevd_L.*kron(eye(k),ones(s,k)))')';
sum_fevd_L=reshape(sum_fevd_L,s,k);
sum_fevd_L=kron(sum_fevd_L,ones(1,k));
w_L=100*fevd_L./sum_fevd_L;

%Setting up results structure
result.IRF_D=imp_resp_D;	
result.IRF_L=imp_resp_L;	
result.FEVD_D=w_D;			
result.FEVD_L=w_L;			
result.u=u;						
result.e=e;

