% ----- example 2.5	
table = randn(5,3);
fprintf(1,'using no options \n');
lprint(table);                     % no printing options used
table2 = round(table)*1000;
fprintf(1,'using fmt option \n');
option.fmt = '%10.0f';
lprint(table2,option);             % format option used
fprintf(1,'using column names and fmt option \n');
vnames = strvcat('Illinois','Ohio','Indiana');
inarg.fmt = '%12.3f';
inarg.cnames = vnames;
lprint(table2,inarg);              % format and column names used
fprintf(1,'row and column labels \n');
inarg.rnames = strvcat('Rows','row1','row2','row3','row4','row5');
lprint(table2,inarg);              % adding row-labels to inarg structure
fprintf(1,'wrapped output for large matrices \n');
vnames = strvcat('IL','OH','IN','WV','PA','AK','HI','NY','MS','TN');
table3 = randn(5,10);
option2.fmt = '%20.4f';
option2.cnames = vnames;
lprint(table3,option2);            % wrapping for large matrices
fprintf(1,'generic row labels \n');
table4 = randn(4,4)*100;
option3.fmt = '%10.4f';
cnames = strvcat('column1','column2','column3','column4');
option3.cnames = cnames;
option3.rflag = 1;
lprint(table4,option3);            % relying on generic row-labels
fprintf(1,'variable column formats \n');
table4(:,1) = round(table4(:,1)); table4(:,3) = round(table4(:,3));
option4.fmt = strvcat('%10d','%8.3f','%10d','%16.3f');
option4.cnames = cnames;
lprint(table4,option4);            % variable column formats 
fprintf(1,'demo of printing selected rows and columns \n');
clear in;
table = randn(5,10);
in.begc = 5;    % specify selected columns to print
in.endc = 9;
in.begr = 2;    % specify selected rows to print
in.endr = 5;
cnames = strvcat('col1','col2','col3','col4');
cnames = strvcat(cnames,'col5','col6','col7','col8','col9','col10');
rnames = strvcat('Rows','row1','row2','row3','row4','row5');
% NOTE we need column and row names for all rows and columns
%      not just those selected for printing
in.cnames = cnames;
in.rnames = rnames;
lprint(table,in);                 % print selected rows and columns
