% ----- example 2.11
% set downturn turning point definition
%        y(t-4) <= y(t-3) <= y(t-2) <= y(t-1) <= y(t)
% which is the condition for a downturn if,
%        y(t+1) < y(t)  we have a downturn
% else no downturn
in.bdt = 4;
in.adt = 1;
in.eq = 1;
% note we use in.eq = 1 (the default)
% to define the weak inequality, rather than strict
in.seq = 0;
% note we use in.seq = 0 (NOT the default)
% to require a sequence of rising values for y prior to the turns

% set upturn turning point definition
%        y(t-4) => y(t-3) >= y(t-2) >= y(t-1) >= y(t)
% which is the condition for a upturn if
%        y(t+1) > y(t)  which is an upturn
% else no upturn
in.but = 4;
in.aut = 1;

% create calendar structure variable
dates = cal(1982,1,12);
load test.dat; % monthly time-series on employment for 8 states
y = growthr(test,dates);    % convert to growth-rates
yt = trimr(y,dates.freq,0); % truncate initial zeros
tdates = cal(1983,1,12);    % update calendar for truncation
ytime = yt(:,1);            % pull out state 1 time-series

results = fturns(ytime,in);
plt(results,tdates,'employment');
title('tight sequential definition of turns --- produces fewer turns');
pause;

% Now, change to a non-sequential definition
in.seq = 1;
% which sets downturn turning point definition to:
%        y(t-4), y(t-3), y(t-2), y(t-1) <= y(t)
% which is the condition for a downturn if,
%        y(t+1) < y(t)  we have a downturn
% else no downturn

% and the upturn turning point definition
%        y(t-4), y(t-3), y(t-2), y(t-1) >= y(t)
% which is the condition for a upturn if
%        y(t+1) > y(t)  which is an upturn
% else no upturn
results = fturns(ytime,in);
plt(results,tdates,'employment');
title('looser non-sequential definition --- produces more turns');
pause;

% Now, illustrate requiring many points after the turns
% which should rule on some of the large # of turns
% seen in the above graph
in.seq = 1;
in.aut = 4; % 4 periods of up after an upturn
in.adt = 4; % 4 periods of down after a downturn
% which sets downturn turning point definition to:
%        y(t-4), y(t-3), y(t-2), y(t-1) <= y(t)
% which is the condition for a downturn if,
%        y(t+4) < y(t+3) < y(t+2) < y(t+1) < y(t)  we have a downturn
% else no downturn

% and the upturn turning point definition
%        y(t-4), y(t-3), y(t-2), y(t-1) >= y(t)
% which is the condition for a upturn if
%        y(t+4) > y(t+3) > y(t+2) > y(t+1) > y(t)  which is an upturn
% else no upturn
results = fturns(ytime,in);
plt_turns(results,tdates,'employment');
title('tighter non-sequential definition --- produces less turns');
pause;
% Now turn on sequential requirement, which
% should produce very very few turns that meet
% this strict definition
in.seq = 0;
results = fturns(ytime,in);
plt(results,tdates,'employment');
title('tightest sequential definition --- produces very few turns');
