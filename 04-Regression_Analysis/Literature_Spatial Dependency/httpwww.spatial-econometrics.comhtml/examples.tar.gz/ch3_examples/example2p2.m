% ----- example 2.2
cstruct = cal(1982,1,4);
for i=1:2;
tsdate(cstruct,i);
end;
