% ----- example 2.12
dates = cal(1982,1,12);     % initialize a calendar
load test.dat;              % load some data
ysdiff = sdiff(test,dates); % seasonally difference the data
ysdiff = trimr(ysdiff,dates.freq,0); % truncate first freq observations
mprint(ysdiff);
