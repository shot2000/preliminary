% ----- example 2.13
% Using the cal() structure
dates = cal(1982,1,12);    % initialize a calendar
load test.dat;             % load some data
y = growthr(test,dates);   % transform to growth rates
y = trimr(y,dates.freq,0); % truncate the first freq observations

% Using `freq=12' as an input argument
y = growthr(test,12);      % transform to growth rates
y = trimr(y,12,0);         % truncate the first freq observations
in.fmt = '%8.2f';
mprint(y,in);
