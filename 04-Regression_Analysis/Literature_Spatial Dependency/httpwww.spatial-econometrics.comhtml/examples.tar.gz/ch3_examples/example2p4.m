% ----- example 2.4
dates = cal(1982,1,12);
load test.dat; % monthly time-series data starting in Jan, 1982
[nobs nvar] = size(test);
% find the date of the last observation
endd = tsdate(dates,nobs);
fprintf(1,'The ending date of the sample is %10s \n\n',endd);
% print data with dates for the year 1990
begin_prt = ical(1990,1,dates);
end_prt   = ical(1990,12,dates);
fprintf(1,'The data for 1990 is: \n\n');
for i=begin_prt:end_prt;
fprintf(1,'%10s ',tsdate(dates,i));
for j=1:nvar
fprintf(1,'%8.0f ',test(i,j));
end;
fprintf(1,'\n');
end;
