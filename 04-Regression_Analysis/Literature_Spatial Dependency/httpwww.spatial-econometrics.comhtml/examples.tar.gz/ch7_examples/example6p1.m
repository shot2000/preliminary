% ----- example 6.1
% Logit and Probit regression models
load spector.dat; % data from Spector and Mazzeo, 1980

y = spector(:,1);
x = spector(:,2:5);

vnames = strvcat('grade','const','psi','tuce','gpa');

reso = ols(y,x);
prt(reso,vnames);

resl = logit(y,x);
prt(resl,vnames);

resp = probit(y,x);
prt(resp,vnames);
