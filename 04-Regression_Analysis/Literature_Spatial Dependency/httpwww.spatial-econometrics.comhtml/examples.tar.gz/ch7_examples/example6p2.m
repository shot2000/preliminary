% ----- example 6.2
% Demonstrate how Albert-Chib latent variable works
nobs=100; nvar=4; % generate a probit data set
randn('seed',1010);
x = rand(nobs,nvar)*5; 
beta = ones(nvar,1);
beta(1,1) = -1; beta(2,1) = -1;
evec = randn(nobs,1);
y = x*beta + evec;
ysave = y;   % save the generate y-values
 for i=1:nobs % convert to 0,1 values
        if y(i,1) >= 0
            y(i,1) = 1;
        else
            y(i,1) = 0;
        end;
 end; 
prior.beta = zeros(4,1);      % diffuse prior for beta
prior.bcov = eye(4)*10000;
ndraw = 1100; nomit = 100;
prior.rval = 100;             % probit prior for r-value
results = probit_g(y,x,prior,ndraw,nomit); 
ymean = mean(results.ydraw)'; % find the mean of draws
tt=1:nobs;
plot(tt,ysave,tt,ymean,'--');
xlabel('observations');
ylabel('actual vs latent variable predictions');
legend('actual','predicted');
