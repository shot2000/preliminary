% ----- example 6.7
% Gibbs and maximum likelihood tobit estimation
n=100; k = 4; sige = 10;
evec = randn(n,1)*sqrt(sige);
x = randn(n,k);
b = ones(k,1); b(1,1) = -1; b(2,1) = -1;
y = x*b + evec;
yc = zeros(n,1);
% now censor the data
for i=1:n
    if y(i,1) >= 0
       yc(i,1) = y(i,1);
	 end;
end;
Vnames = strvcat('y','x1','x2','x3','x4');
prt(tobit(yc,x),Vnames);

prior.bcov = eye(k)*1000; % diffuse prior var-cov for b
prior.beta = zeros(k,1);  % diffuse prior means for b
prior.rval = 100;         % homoscedastic prior
ndraw = 1500; nomit = 100;
result = tobit_g(yc,x,prior,ndraw,nomit);
prt(result,Vnames);
