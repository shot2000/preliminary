% ----- example 6.3
% Logit Gibbs estimation
nobs=100; nvar=4; % generate data
x = randn(nobs,nvar)*2; 
beta = ones(nvar,1);
beta(1,1) = -1; beta(2,1) = -1;
evec = randn(nobs,1);
xb = x*beta + evec;
y = exp(xb)./(ones(nobs,1) + exp(xb)); % logit model generation
ysave = y;
for i=1:nobs;  % convert to 0,1 values
        if ysave(i,1) >= 0.5
            y(i,1) = 1;
    else
            y(i,1) = 0;
    end;
end;
prt(logit(y,x)); % print out maximum likelihood estimates
ndraw = 2100; nomit = 100;
prior.beta = zeros(4,1);  % diffuse prior means for beta
prior.bcov = eye(4)*10000;% diffuse prior variance for beta       
prior.rval = 7;           % logit prior r-value  
resp = probit_g(y,x,prior,ndraw,nomit); % Gibbs sampling
prt(resp);                % print Gibbs probit results
         
