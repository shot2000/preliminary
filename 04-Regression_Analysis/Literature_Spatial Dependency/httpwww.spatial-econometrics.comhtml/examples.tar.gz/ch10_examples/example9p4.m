% ----- Example 9.4 Using the optsolv() function
n=200; k=8; randn('seed',20201);
x = randn(n,k); beta = ones(k,1);
y = x*beta + randn(n,1); % generate uncensored data
for i=1:n                % now censor the data
  if y(i,1) < 0,y(i,1) = 0.0;
  end;
end;     
% ols starting values
res = ols(y,x); b = res.beta; sige = res.sige; 
parm = [b  
        sige];  % starting values                      
% solve using solvopt routine
info.x = x; info.y = y;
tic; 
[parm1,like1,hess1,grad1,niter1] = optsolv('to_like1',parm,info);
disp('time taken by optsolv routine');
toc;
% solve using maxlik routine
tic;
[parm2,hess2,grad2,like2,niter2] = maxlik('to_like1',parm,info);
disp('time taken by maxlik routine'); toc;
in.fmt = '%9.3f'; fprintf(1,'comparison of estimates \n');
mprint([parm1 parm2],in);
fprintf(1,'comparison of log likelihood function values \n');
mprint([like1 like2],in);
in.fmt = '%8.3f';
fprintf(1,'comparison of hessians \n');
mprint(hess1,in); mprint(inv(hess2),in);
in.fmt = '%8d';
fprintf(1,'comparison of # of iterations \n');
mprint([niter1 niter2],in);
