% --- Example 9.1 Simplex maximum likelihood
%     estimation of the Box-Cox model using
%     MATLAB fmin simplex optimization function

% generate box-cox model data
n = 100; k = 2; nexper = 100;
x = abs(randn(n,k)) + ones(n,k)*10;; 
btrue = ones(k,1); 
x(:,1) = ones(n,1);
bsave = zeros(nexper,k);
ssave = zeros(nexper,1);
lsave = zeros(nexper,1);
for iter = 1:nexper;
y = x*btrue + randn(n,1)*0.5;
ycheck = find(y > 0);
if length(ycheck) ~= n
   error('all y-values must be positive');
end;
yt = exp(y); % should produce lambda = 0 estimate
model = 0;   % transform only y-variable
result = box_cox(yt,x,-2,2,model);
bsave(iter,:) = result.beta';
lsave(iter,1) = result.lam;
ssave(iter,1) = result.sige;
end;
fprintf(1,'average of estimates over 100 experiments \n');
fprintf(1,'beta hat estimates = %16.4f \n',mean(bsave));
fprintf(1,'lambda estimate    = %16.4f \n',mean(lsave));
fprintf(1,'sigma estimate     = %16.4f \n',mean(ssave));

model = 1;   % transform both y,x variables
bsave = zeros(nexper,k);
ssave = zeros(nexper,1);
lsave = zeros(nexper,1);
for iter = 1:nexper;
y = x*btrue + randn(n,1)*0.5;
yt = y; xt = x; % should produce lambda = 1 estimate
ycheck = find(yt > 0); xcheck = find(xt > 0);
if (length(ycheck) ~= n) & (length(xcheck) ~= n*k)
   error('all y, x-values must be positive');
end;
result = box_cox(yt,xt,-2,2,model);
bsave(iter,:) = result.beta';
lsave(iter,1) = result.lam;
ssave(iter,1) = result.sige;
end;
fprintf(1,'average of estimates over 100 experiments \n');
fprintf(1,'beta hat estimates = %16.4f \n',mean(bsave));
fprintf(1,'lambda estimate    = %16.4f \n',mean(lsave));
fprintf(1,'sigma estimate     = %16.4f \n',mean(ssave));
