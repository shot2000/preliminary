% PURPOSE: An example using dfp_min, frpr_min, pow_min, maxlik
%                           
%  to solve a Tobit (censored) regression maximum
%  likelihood problem                           
%---------------------------------------------------
% USAGE: optim_d
%---------------------------------------------------

% generate uncensored data
n=200; k=8; randn('seed',20201); x = randn(n,k); beta = ones(k,1);
y = x*beta + randn(n,1);
% now censor the data
for i=1:n
 if y(i,1) < 0, y(i,1) = 0.0; end;
end;
% use ols for starting values
res = ols(y,x); b = res.beta; sige = res.sige;
 parm = [b  
        sige];  % starting values    
info.maxit = 1000;   
% solve using frpr_min routine
tic; [parm1,like1,hess1,niter1] = frpr_min('to_like1',parm,info,y,x);
disp('time taken by frpr routine'); toc;
% solve using dfp_min routine
tic; [parm2,like2,hess2,niter2] = dfp_min('to_like1',parm,info,y,x);
disp('time taken by dfp routine'); toc;
% solve using pow_min routine
tic; [parm3,like3,hess3,niter3] = pow_min('to_like1',parm,info,y,x);
disp('time taken by powell routine'); toc;
% solve using maxlik routine
info2.method = 'bfgs'; 
tic; [parm4,like4,hess4,grad,niter4,fail] = maxlik('to_like1',parm,info2,y,x);
disp('time taken by maxlik routine'); toc;
% formatting information for mprint routine
in.cnames = strvcat('fprf','dfp','powell','bfgs'); in.fmt = '%8.4f';
fprintf(1,'comparison of bhat estimates \n');
mprint([parm1(1:k,1) parm2(1:k,1) parm3(1:k,1) parm4(1:k,1)],in);
fprintf(1,'comparison of sige estimates \n');
mprint([parm1(k+1,1) parm2(k+1,1) parm3(k+1,1) parm4(k+1,1)],in);
fprintf(1,'comparison of likelihood functions \n');
mprint([like1 like2 like3 like4],in);
in.fmt = '%4d'; fprintf(1,'comparison of # of iterations \n');
mprint([niter1 niter2 niter3 niter4],in);
fprintf(1,'comparison of hessians \n'); in2.fmt = '%8.2f';
fprintf(1,'fprf hessian');   mprint(hess1,in2);
fprintf(1,'dfp hessian');    mprint(hess2,in2);
fprintf(1,'powell hessian'); mprint(hess3,in2);
fprintf(1,'maxlik hessian'); mprint(hess4,in2);


