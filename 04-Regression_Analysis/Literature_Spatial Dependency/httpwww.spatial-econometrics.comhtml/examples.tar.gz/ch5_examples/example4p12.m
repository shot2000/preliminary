% ----- example 4.12
dates = cal(1982,1,12); % data starts in 1982,1
y=load('sic33.states'); % industry sic33 employment for 8 states
[nobs neqs] = size(y);
load sic33.national;    % industry sic33 national employment
ndates = cal(1947,1,12);% national data starts in 1947,1

begs = ical(1982,1,ndates); % find 1982,1 for national data
ends = ical(1996,5,ndates); % find 1996,5 for national data

x = sic33(begs:ends,1); % pull out national employment in sic33
                        % for the time-period corresponding to
                        % our 8-state sample
begf = ical(1990,1,dates);  % begin forecasting date
endf = ical(1994,12,dates); % end forecasting date
nfor = 12;                  % forecast 12-months-ahead
nlag = 6;
xerror = zeros(nfor,1);
yerror = zeros(nfor,neqs);
cnt = 0; % counter for the # of forecasts we produce
for i=begf:endf % loop over dates producing forecasts
xactual = x(i:i+nfor-1,1); % actual national employment
yactual = y(i:i+nfor-1,:); % actual state employment
% first forecast national employment in sic33
xfor = varf(x,nlag,nfor,i); % an ar(6) model
xdet = [x(1:i-1,1)          % actual national data up to forecast period
        xfor      ];        % forecasted national data
% do state forecast using national data and forecast as input
yfor = varf(y,nlag,nfor,i,xdet);
% compute forecast percentage errors
xerror = xerror + abs((xactual-xfor)./xactual);
yerror = yerror + abs((yactual-yfor)./yactual);
cnt = cnt+1;
end; % end loop over forecasting experiment dates
% compute mean absolute percentage errors
xmape = xerror*100/cnt; ymape = yerror*100/cnt;
% print-out results
in.cnames =  strvcat('national','il','in','ky','mi','oh','pa','tn','wv');
rnames = 'Horizon';
for i=1:12; rnames = strvcat(rnames,[num2str(i),'-step']); end;
in.rnames = rnames;
in.fmt = '%6.2f';
fprintf(1,'national and state MAPE percentage forecast errors \n');
fprintf(1,'based on %d 12-step-ahead forecasts \n',cnt);
mprint([xmape ymape],in);
