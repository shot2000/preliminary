% ----- example 4.2
dates = cal(1982,1,12);
load test.dat; % monthly mining employment in 8 states
                      % convert to growth-rates
y = growthr(test,12); % use all eight states
yt = trimr(y,dates.freq,0);  % truncate 
% redefine the calendar based on truncation
dates = cal(1983,1,1);
vnames  = strvcat('il','in','ky','mi','oh','pa','tn','wv');             
nlag = 12;
result = var(yt,nlag);  % estimate 12-lag VAR model
cutoff = 0.1;           % examine Granger-causality at 90% level
pgranger(result,vnames,cutoff);  % print Granger probabilities
