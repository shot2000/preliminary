% ----- example 4.13
% comparison of forecast accuracy as a function of
% the # of co-integrating vectors used
load level.mat;    % 20 industries national employment
y = level(:,1:12); % use only 12 industries
[nobs neqs] = size(y);
dates = cal(1947,1,12);    
begf = ical(1970,1,dates);  % beginning forecast date
endf = ical(1995,12,dates); % ending forecast date
nfor = 12;                  % forecast horizon
nlag = 10; % based on lrratio() results
cnt = 1;
for i=begf:endf;
jres = johansen(y,0,nlag);
% find r indicated by trace statistic
 trstat = jres.lr1;
 tsignf = jres.cvt;
 r = 0;
 for j=1:neqs;
   if trstat(j,1) > tsignf(j,2)
   r = j;
   end;
 end;
% set up r-1,r-2 and r+1,r+2 forecasts
% in addition to forecasts based on r
if (r >= 3 & r <=10)
 frm2 = ecmf(y,nlag,nfor,i,r-2); frm1 = ecmf(y,nlag,nfor,i,r-1);
 fr   = ecmf(y,nlag,nfor,i,r);   frp1 = ecmf(y,nlag,nfor,i,r+1);
 frp2 = ecmf(y,nlag,nfor,i,r+2); actual = y(i:i+nfor-1,1:12);
 % compute forecast MAPE
 error(cnt).rm2 = abs((actual-frm2)./actual);
 error(cnt).rm1 = abs((actual-frm1)./actual);
 error(cnt).r   = abs((actual-fr)./actual);
 error(cnt).rp1 = abs((actual-frp1)./actual);
 error(cnt).rp2 = abs((actual-frp2)./actual);
 cnt = cnt+1;
else
 fprintf(1,'time %d had %d co-integrating relations \n',i,r);
end;
end; % end of loop over time
rm2 = zeros(12,12); rm1 = zeros(12,12); rm0 = zeros(12,12);
rp1 = zeros(12,12); rp2 = zeros(12,12);
for i=1:cnt-1;
rm2 = rm2 + error(i).rm2; rm1 = rm1 + error(i).rm1;
rm0 = rm0 + error(i).r;   rp1 = rp1 + error(i).rp1;
rp2 = rp2 + error(i).rp2;
end;
rm2 = rm2/(cnt-1);        rm1 = rm1/(cnt-1);
rm0 = rm0/(cnt-1);        rp1 = rp1/(cnt-1);
rp2 = rp2/(cnt-1);
rnames = 'Horizon'; cnames = [];
for i=1:12; 
rnames = strvcat(rnames,[num2str(i),'-step']); 
cnames = strvcat(cnames,['IND',num2str(i)]);
end;
in.rnames = rnames; in.cnames = cnames; in.fmt = '%6.2f';
fprintf(1,'forecast errors relative to error by ecm(r) model \n');
fprintf(1,'r-2 relative to r \n');
mprint(rm2./rm0,in);
fprintf(1,'r-1 relative to r \n');
mprint(rm2./rm0,in);
fprintf(1,'r+1 relative to r \n');
mprint(rp1./rm0,in);
fprintf(1,'r+2 relative to r \n');
mprint(rp2./rm0,in);
