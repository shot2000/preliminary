% ----- example 4.1
dates = cal(1982,1,12);
load test.dat; % monthly mining employment in 8 states
y = growthr(test(:,1:2),12); % convert to growth-rates
yt = trimr(y,dates.freq,0);  % truncate 
% redefine the calendar based on truncation
dates = cal(1983,1,1);
vnames   = strvcat('illinos','indiana');
nlag = 2;
result = var(yt,nlag);       % estimate 2-lag VAR model
prt(result,vnames);          % print-out results
