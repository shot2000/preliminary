% ----- example 4.3
dates = cal(1982,1,12);
load test.dat;
y = test; % use levels data
[nobs neqs] = size(test);
sdum = sdummy(nobs,dates.freq); % create seasonal dummies
sdum = trimc(sdum,1,0);         % omit 1 column because we have 
                                % a constant included by var()
vnames  = strvcat('illinos','indiana','kentucky','michigan','ohio',  ...   
           'pennsylvania','tennessee','west virginia');  
dnames = strvcat('dum1','dum2','dum3','dum4','dum5','dum6','dum7','dum8', ...
          'dum9','dum10','dum11');
vnames  = strvcat(vnames,dnames);		   
nlag = 12;
result = var(y,nlag,sdum);
prt(result,vnames);
