% ----- example 4.8
vnames =  strvcat('il','in','ky','mi','oh','pa','tn','wv');      
y = load('test.dat'); % use all eight states
nlag = 2;
tight = 0.1;  % hyperparameter values
weight = 0.5;
decay = 1.0;
result = bvar(y,nlag,tight,weight,decay);
prt(result,vnames);
