% ----- example 4.4
load test.dat;
y = test; % use all eight states
maxlag = 12;
minlag = 3;
% Turn on flag for Sim's correction factor
sims = 1;
disp('LR-ratio results with Sims correction');
lrratio(y,maxlag,minlag,sims);
