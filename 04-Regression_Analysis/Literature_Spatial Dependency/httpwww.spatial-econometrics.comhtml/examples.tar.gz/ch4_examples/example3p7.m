% ----- example 3.7
nobs = 100; nvar = 3;
x = randn(nobs,nvar); x(:,1) = ones(nobs,1);
beta = ones(nvar,1); evec = randn(nobs,1);
y = x*beta + evec;
% put in 2 outliers
y(75,1) = 10.0; y(90,1) = -10.0;
% get weighting parameter from OLS
% (of course you're free to do differently)
reso = ols(y,x);
sige = reso.sige;
% set up storage for bhat results
bsave = zeros(nvar,5); bsave(:,1) = ones(nvar,1);
% loop over all methods producing estimates
for i=1:4;
wfunc = i; wparm = 2*sige; % set weight to 2 sigma
res = robust(y,x,wfunc,wparm);
bsave(:,i+1) = res.beta;
end;
in.cnames = strvcat('Truth','Huber t','Ramsay','Andrews','Tukey');
in.rnames = strvcat('Coefficients','beta1','beta2','beta3');
in.fmt = '%10.4f';
mprint(bsave,in);
res = robust(y,x,4,2);
prt(res); % demonstrate prt and plt functions
plt(res);
