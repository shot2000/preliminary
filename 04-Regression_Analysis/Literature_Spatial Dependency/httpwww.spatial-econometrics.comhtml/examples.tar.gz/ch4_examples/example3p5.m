% ----- example 3.5
n = 100; k = 5;
x = randn(n,k); e = randn(n,1); b = ones(k,1);
% generate collinear data
x(:,1) = x(:,2) + x(:,4) + randn(n,1)*0.1;
y = x*b + e;
% set up prior information
c = ones(k,1); % prior means
sigu = eye(k); % prior variances
R = eye(k);
reso = ols(y,x); % ols
prt(reso);
res = theil(y,x,c,R,sigu); %theil
prt(res);	
