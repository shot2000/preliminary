% ----- Example 3.1
n=100; k=4; u1 = randn(n,1); u2=u1*0.5; u3 = u1*0.1;
x1 = [ones(n,1) rand(n,k-1)]; % orthgonal x's
x2 = [x1(:,1:2) x1(:,4)+u1 x1(:,4)]; % collinear set 1
x3 = [x1(:,1:2) x1(:,4)+u2 x1(:,4)]; % collinear set 2
x4 = [x1(:,1:2) x1(:,4)+u3 x1(:,4)]; % collinear set 3
ndraws = 1000; beta = ones(k,1);
bsave1 = zeros(ndraws,k); bsave2 = zeros(ndraws,k);
bsave3 = zeros(ndraws,k); bsave3 = zeros(ndraws,k);
for i=1:ndraws; % do 1000 experiments
e = randn(n,1);
y = x1*beta + e;
res = ols(y,x1);
b1save(i,:) = res.beta';
y = x2*beta + e;
res = ols(y,x2);
b2save(i,:) = res.beta';
y = x3*beta + e;
res = ols(y,x3);
b3save(i,:) = res.beta';
y = x4*beta + e;
res = ols(y,x4);
b4save(i,:) = res.beta';
end;
% compute means and std deviations for betas
mtable = zeros(4,k);
stable = zeros(4,k);
mtable(1,:) = mean(b1save); mtable(2,:) = mean(b2save);
mtable(3,:) = mean(b3save); mtable(4,:) = mean(b4save);
stable(1,:) = std(b1save); stable(2,:) = std(b2save);
stable(3,:) = std(b3save); stable(4,:) = std(b4save);
% print tables
in.cnames = strvcat('alpha','beta','gamma','theta');
in.rnames = strvcat('beta means   ','benchmark','sigu=1.0','sigu=0.5','sigu=0.1');
in.fmt = '%10.4f';
mprint(mtable,in);
in.rnames = strvcat('std deviation','benchmark','sigu=1.0','sigu=0.5','sigu=0.1');
mprint(stable,in);


