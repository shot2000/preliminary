% ----- example 3.8
n = 100;
y1 = randn(n,1);
y2 =  2*y1 + randn(n,1);
y3 = -2*y2 + randn(n,1);
y4 = randn(n,1);    % uncorrelated with y1,y2,y3
y5 = randn(n,1).^4; % leptokurtic variable
y = [y1 y2 y3 y4 y5];
vnames = strvcat('apples','oranges','pairs','ha ha','leptoku');
pairs(y,vnames);
