% ----- example 5.6
% Heteroscedastic Gibbs Sampling Example:
n=100; k=3; % set number of observations and variables
randn('seed',202112);
x = randn(n,k); b = ones(k,1);  % generate data set
tt = ones(n,1); tt(51:100,1) = [1:50]';
y = x*b + randn(n,1).*sqrt(tt); % heteroscedastic disturbances
ndraw = 1100; nomit = 100;      % set the number of draws     
bsave = zeros(ndraw,k);         % allocate storage for results
ssave = zeros(ndraw,1);  rsave = zeros(ndraw,1);
vsave = zeros(ndraw,n);
r = [1.0 1.0 1.0]';             % prior b means
R = eye(k); T = eye(k)*0.5;	    % prior b variance 
Q = chol(inv(T)); q = Q*r;
b0 = (x'*x)\(x'*y);             % use ols starting values
sige = (y-x*b0)'*(y-x*b0)/(n-k);	
V = ones(n,1); in = ones(n,1);  % initial value for V
rval = 4;                       % initial value for rval
qpq = Q'*Q; qpv = Q'*q;         % calculate Q'Q, Q'q only once
mm=8; kk=2;                     % prior for r-value
                                % mean(rvalue) = 4, var(rvalue) = 2
tic;
for i=1:ndraw;                  % Start the sampling
  ys = y.*sqrt(V); xs = matmul(x,sqrt(V));
  xpxi = inv(xs'*xs + sige*qpq);
  b = xpxi*(xs'*ys + sige*qpv); % update b 
  b = norm_rnd(sige*xpxi) + b;  % draw MV normal mean(b), var(b)
  bsave(i,:) = b';              % save b draws
  e = y - x*b; ssr = e'*e;      % update sige
  chi = chis_rnd(1,n);          % do chisquared(n) draw 
  sige = ssr/chi; ssave(i,1) = sige; % save sige draws
  chiv = chis_rnd(n,rval+1);    % update vi
  vi = ((e.*e./sige) + in*rval)./chiv;
  V = in./vi; vsave(i,:) = vi'; % save the draw  
  rval = gamm_rnd(1,1,mm,kk);   % update rval
  rsave(i,1) = rval;            % save the draw
end;                            % End the sampling
toc;
bhat = mean(bsave(nomit+1:ndraw,:));  % calculate means and std deviations
bstd = std(bsave(nomit+1:ndraw,:)); tstat = bhat./bstd;
smean = mean(ssave(nomit+1:ndraw,1));
vmean = mean(vsave(nomit+1:ndraw,:));
rmean = mean(rsave(nomit+1:ndraw,1));
tout = tdis_prb(tstat',n); % compute t-stat significance levels
% set up for printing results
in.cnames = strvcat('Coefficient','t-statistic','t-probability');
in.rnames = strvcat('Variable','variable 1','variable 2','variable 3');
in.fmt = '%16.6f';
tmp = [bhat' tstat' tout];
fprintf(1,'Gibbs estimates \n'); % print results
mprint(tmp,in);
fprintf(1,'Sigma estimate = %16.8f \n',smean);
fprintf(1,'rvalue estimate = %16.8f \n',rmean);
result = theil(y,x,r,R,T); % compare to Theil-Golberger estimates
prt(result);
plot(vmean); % plot vi-estimates
title('mean of vi-estimates');