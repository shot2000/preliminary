% ----- example 5.5
n=100; k=3; % set number of observations and variables
randn('seed',10101);
x = randn(n,k); b = ones(k,1); % generate data set
randn('seed',20201);
y = x*b + randn(n,1);
ndraw1 = 600; nomit = 100; % set the number of draws   
r = [1.0 1.0 1.0]';        % prior b means
R = eye(k); T = eye(k);	   % prior b variance 
rval = 100;                % homoscedastic prior for r-value
prior.beta = r; prior.bcov = T;
prior.rmat = R; prior.rval = rval;
start1.b = zeros(k,1);
start1.sig = 1.0;
start1.V = ones(n,1);
result1 = ols_g(y,x,prior,ndraw1,nomit,start1);
gres1 = gmoment(result1.bdraw);
start2.b = ones(k,1);
start2.sig = 10.0;
start2.V = start1.V;
ndraw2 = 1100;
result2 = ols_g(y,x,prior,ndraw2,nomit,start2);
gres2 = gmoment(result2.bdraw);
result = apm(gres1,gres2);
prt(result)