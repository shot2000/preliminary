% ----- example 7.2
% Monte Carlo study of two-stage vs. least-squares
nobs = 200;
x1 = randn(nobs,1); x2 = randn(nobs,1);
b1 = 1.0; b2 = 1.0; iota = ones(nobs,1);
y1 = zeros(nobs,1); y2 = zeros(nobs,1);
evec = randn(nobs,1);
% create simultaneously determined variables y1,y2
for i=1:nobs;
y1(i,1) = iota(i,1) + x1(i,1)*b1 + evec(i,1);
y2(i,1) = iota(i,1) + y1(i,1) + x2(i,1)*b2 + evec(i,1);
end;       
% use all exogenous in the system as instruments
xall = [iota x1 x2];            
niter = 100;            % number of Monte Carlo loops
bols  = zeros(niter,3); % storage for ols results
b2sls = zeros(niter,3); % storage for 2sls results
disp('patience -- doing 100 2sls regressions');
for iter=1:niter;
y1 = zeros(nobs,1);  y2 = zeros(nobs,1); evec = randn(nobs,1);
% create simultaneously determined variables y1,y2
for i=1:nobs;           % do Monte Carlo looping
y1(i,1) = iota(i,1)*1.0 + x1(i,1)*b1 + evec(i,1);
y2(i,1) = iota(i,1)*1.0 + y1(i,1)*1.0 + x2(i,1)*b2 + evec(i,1);
end;
result1 = ols(y2,[y1 iota x2]);       % do ols regression
result2 = tsls(y2,y1,[iota x2],xall); % do tsls regression
bols(iter,:)  = result1.beta';
b2sls(iter,:) = result2.beta';
end;                    % end Monte Carlo looping
% find means and std deviations over the niter runs
bolsm = mean(bols); b2slsm = mean(b2sls);
bolss = std(bols);  b2slss = std(b2sls);
% print results 
fprintf(['OLS results over ',num2str(niter),' runs\n']);
in.rnames = strvcat('Coefficients','b1','b2','b3');
in.cnames = strvcat('Mean','std dev');
mprint([bolsm' bolss'],in);
fprintf(['TSLS results over ',num2str(niter),' runs\n']);
mprint([b2slsm' b2slss'],in);


