% PURPOSE: An example using sur_iter(),
%                           
% seemingly unrelated regression estimation
% with iteration on the error var-cov matrix                              
%---------------------------------------------------
% USAGE: sur_iterd
%---------------------------------------------------

load grun.dat; % grunfeld investment data
                % see page 650, Green 1997

y1  = grun(:,1); % general electric
x11 = grun(:,2);
x12 = grun(:,3);
nobs = length(y1);
iota = ones(nobs,1);

y2  = grun(:,4); % westinghouse
x21 = grun(:,5);
x22 = grun(:,6);

vname1 = ['I gen electr  ',
          'constant      ',
          'fge           '
          'cge           '];
          
vname2 = ['I westinghouse',
          'constant      ',
          'fwest         '
          'cwest         '];

        
% set up a structure for y containing y's for each eqn
% (order follows that in Green, 1997)

y(1).eq = y1; % general electric
y(2).eq = y2; % westinghouse

% set up a structure for X in each eqn
X(1).eq = [iota x11 x12];
X(2).eq = [iota x21 x22];

% do sur regression with iteration
neqs = 2;
iflag = 1;
result = sur(neqs,y,X,iflag);

% no iteration done here
result2 = sur(neqs,y,X);

vname = [vname1
         vname2];

prt(result,vname);
prt(result2,vname);


