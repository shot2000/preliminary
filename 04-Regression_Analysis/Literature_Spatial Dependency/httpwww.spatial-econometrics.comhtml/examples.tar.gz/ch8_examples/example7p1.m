% ----- example 7.1
% Two-stage least-squares regression model
nobs = 200;
x1 = randn(nobs,1);  x2 = randn(nobs,1);
b1 = 1.0; b2 = 1.0;  iota = ones(nobs,1);
y1 = zeros(nobs,1);  y2 = zeros(nobs,1); 
evec = randn(nobs,1);
% create simultaneously determined variables y1,y2
for i=1:nobs;
y1(i,1) = iota(i,1) + x1(i,1)*b1 + evec(i,1);
y2(i,1) = iota(i,1) + y1(i,1)*1.0 + x2(i,1)*b2 + evec(i,1);
end;
vname1 = strvcat('y1-eqn','y2 variable','constant','x1 variable');
vname2 = strvcat('y2-eqn','y1 variable','constant','x2 variable');
% use all exogenous in the system as instruments
xall = [iota x1 x2];            
% do ols regression for comparison with two-stage estimates
result1 = ols(y2,[y1 iota x2]);
prt_reg(result1,vname2);
% do tsls regression
result2 = tsls(y2,y1,[iota x2],xall); 
prt_reg(result2,vname2);

