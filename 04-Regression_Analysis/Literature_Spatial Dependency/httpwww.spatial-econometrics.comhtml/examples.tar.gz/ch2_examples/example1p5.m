% ----- example 1.5
% demonstrate computation of Cochrane-Orcutt and
% maximum likelihood estimates for the AR(1) errors model
% y = x*b + u,    u = rho*ulag + e
% generate a model with 1st order serial correlation
n = 200; k = 3; 
evec = randn(n,1); xmat = randn(n,k); xmat(:,1) = ones(n,1);
beta = ones(k,1); beta(1,1) = 10.0; % constant term
y = zeros(n,1); u = zeros(n,1);
for i=2:n;
	u(i,1) = 0.4*u(i-1,1) + evec(i,1);
	y(i,1) = xmat(i,:)*beta + u(i,1);
end;
% truncate 1st 100 observations for startup
yt = y(101:n,1); xt = xmat(101:n,:);
n = n-100; % reset n to reflect truncation
Vnames = strvcat('y','cterm','x2','x3');         
result = ols(yt,xt);
prt_reg(result,Vnames);
plt_reg(result);

% ----- Example 1.6 Cochrane-Orcutt iteration
% NOTE: assumes xt,yt exist (from example 1.5) 
% ----- iterated Cochrane-Orcutt example
converg = 1.0; rho = 0.0; iter = 1;
xtmp = lag(xt,1); ytmp = lag(yt,1);
% truncate 1st observation to feed the lag
xlag = xtmp(2:n,:); ylag = ytmp(2:n,1);
y = yt(2:n,1); x = xt(2:n,:);
Vnames = strvcat('ystar','istar','x2star','x3star');        
n = n-1; % adjust n to account for truncation
disp('Cochrane-Orcutt Estimates');          
while (converg > 0.0001),
 % step 1, using intial rho = 0, do OLS to get bhat
   ystar = y - rho*ylag; xstar = x - rho*xlag;	
   res = ols(ystar,xstar);
 % compute residuals based on beta ols estimates
   e = y - x*res.beta; elag = lag(e);
 % truncate 1st observation to account for the lag
  et = e(2:n,1); elagt = elag(2:n,1);
 % step 2, update estimate of rho using residuals from step 1
  res_rho = ols(et,elagt);
  rho_last = rho;
  rho = res_rho.beta(1);
  converg = abs(rho - rho_last);
 fprintf(1,'rho = %8.5f, converg = %8.5f, iter = %2d \n',rho,converg,iter);
 iter = iter + 1;
end; % end of while loop
% after convergence produce a final set of estimates using rho-value
ystar = y - rho*ylag; xstar = x - rho*xlag;
res = ols(ystar,xstar);
prt_reg(res,Vnames);

% ----- example 1.7
% maximum likelihood estimation of rho and bhat
% set up initial values (using Cochrane-Orcutt estimates)
param = zeros(k+2,1);
param(1,1) = rho;              % initial rho
param(2:2+k-1,1) = res.beta;   % initial bhat's
options(1,1) = 0;      % no print of intermediate results
options(2,1) = 0.0001; % simplex convergence criteria
options(3,1) = 0.0001; % convergence criteria for function value
options(4,1) = 1000;   % default number of function evaluations
[mrho fvalue niter] = fmins('ar1_like',param,options,[],y,x);
% find sige estimate based on ml rho and bhat's
ystar = y - rho*ylag; xstar = x - rho*xlag;
bhat = mrho(2:2+k-1,1);
sige = (ystar - xstar*bhat)'*(ystar - xstar*bhat);
sige = sige/(n-k);
fprintf(1,'Maximum likelihood estimate of rho   = %8.4f \n',mrho(1,1));
fprintf(1,'Maximum likelihood estimate of sigma = %8.4f \n',sige);
fprintf(1,'Maximum likelihood estimates of bhat = %8.4f \n',bhat);
fprintf(1,'negative of Log-likelihood value     = %8.4f \n\n',fvalue);
fprintf(1,'number of iterations taken           = %4d \n\n',niter);
