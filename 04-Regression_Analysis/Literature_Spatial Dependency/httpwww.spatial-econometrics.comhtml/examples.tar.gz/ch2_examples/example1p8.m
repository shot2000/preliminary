% ----- example 1.8
% An example of Wald's F-test
nobs = 200; nvar = 10;
beta = ones(nvar,1); beta(7:nvar,1) = 0.0;
xmat1 = randn(nobs,nvar-1); 
x = [ones(nobs,1) xmat1]; % unrestricted data set
evec = randn(nobs,1)*5;
y = x*beta + evec;
x2 = x(:,1:5);       % restricted data set
resultu = ols(y,x);  % do unrestricted ols regression
prt_reg(resultu);
resultr = ols(y,x2); % do restricted ols regression
prt_reg(resultr);
% test the restrictions
[fstat fprob] = waldf(resultr,resultu);
disp('Wald F-test results');
[fstat fprob]
