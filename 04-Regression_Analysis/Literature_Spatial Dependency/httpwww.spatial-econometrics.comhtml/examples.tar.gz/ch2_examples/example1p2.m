% ----- example 1.2
% determine timing information for the least-squares problem
n = 10000; k = 10;
e = randn(n,1); x = randn(n,k); b = ones(k,1);
y = x*b + e;
disp('time needed for Cholesky solution');
tic;
xpxi = (x'*x)\eye(k); % solve using the Cholesky decomposition
bhatc = xpxi*(x'*y);
toc;
disp('time needed for QR solution');
tic;
[q r] = qr(x,0);      % solve using the qr decomposition
xpxi = (r'*r)\eye(k);
bhatq = r\(q'*y);
toc;
