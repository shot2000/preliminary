% ----- example 1.9
% demonstrate use of lmtest
nobs = 200; nvar = 7;
beta = ones(nvar,1); beta(6:nvar,1) = 0.0;
xmat1 = randn(nobs,nvar-1); 
x = [ones(nobs,1) xmat1]; % unrestricted data set
xr = x(:,1:5);            % restricted data set
evec = randn(nobs,1)*5;
y = x*beta + evec;
resultr = ols(y,xr); % do restricted ols regression
prt_reg(resultr);
% do LM - test
[lmstat lmprob result_lm] = lmtest(resultr,x);
disp('LM-test regression results');
prt_reg(result_lm);
disp('LM test results');
[lmstat lmprob]
