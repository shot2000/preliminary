n = 100; k = 5;
x = randn(n,k);
b = ones(k,1);
y = x*b + randn(n,1);

in.fid = fopen('y.data','w');
in.fmt = '%10.2f';
mprint(y,in);

in.fid = fopen('x.data','w');
mprint(x,in);
