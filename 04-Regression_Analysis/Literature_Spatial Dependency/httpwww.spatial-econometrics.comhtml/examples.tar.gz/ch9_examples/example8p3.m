% ----- example 8.3
% demonstrate left- and right-truncated normal draws
n = 10000; x = zeros(n,1);
% generate from -infinity < 0
for i=1:n; x(i,1) = nmrt_rnd(0); end;
subplot(3,1,1), hist(x,20); xlabel('right-truncated at zero normal');
% generate from 1 < infinity
for i=1:n; x(i,1) = nmlt_rnd(1); end;
subplot(3,1,2), hist(x,20); xlabel('left-truncated at +1 normal');
% generate from -1 < +infinity 
for i=1:n; x(i,1) = nmlt_rnd(-1); end;
subplot(3,1,3), hist(x,20); xlabel('left-truncated at -1 normal');
