% ----- example 6.6
% Maximum likelihood tobit estimation
% generate uncensored data
n=100; k=2;
x = randn(n,k);
x(:,1) = ones(n,1);
beta = ones(k,1)*2.0;
beta(1,1) = -2.0;
beta(2,1) = -2.0;
y = x*beta + randn(n,1);
% now censor the data
for i=1:n
	if y(i,1) < 0
	y(i,1) = 0.0;
	end;
end;
vnames = strvcat('y','x1','x2');        
tic;
resp = tobit(y,x);
toc;
prt(resp,vnames);
tic;
resp = tobit(y,x,'bhhh');
toc;
prt(resp,vnames);
tic;
resp = tobit(y,x,'dfp');
toc;
prt(resp,vnames);
