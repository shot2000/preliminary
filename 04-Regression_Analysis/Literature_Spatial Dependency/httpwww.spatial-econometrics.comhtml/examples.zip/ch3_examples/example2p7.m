% ----- example 2.7
vnames  = strvcat('illinos','indiana','kentucky','michigan','ohio',  ...   
           'pennsylvania','tennessee','west virginia');    
dates = cal(1982,1,12);
load test.dat;
y = test;
fmt = '%16.0f';
begp = ical(1990,1,dates);
endp = ical(1990,12,dates);
tsprint(y,dates,begp,endp,vnames,fmt);
vnames  = strvcat('IL','IN','KY','MI','OH','PA','TN','WV');
fmt = '%6.2f';
tsprint(y,dates,begp,endp,vnames,fmt);
fmt = '%20d';
tsprint(y,dates,begp,endp,vnames,fmt);
