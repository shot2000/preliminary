% ----- example 2.10
dates = cal(1982,1,12);
load test.dat;
y = growthr(test,12);
yt = trimr(y,dates.freq,0);
% redefine the calendar based on truncation
dates = cal(1983,1,12);
vnames  = strvcat('IL','IN','KY','MI','OH','PA','TN','WV');  
subplot(211),
% a plot of the whole time-series sample
tsplot(yt,dates,vnames);
% add a title to the first plot
title('Entire data sample');
subplot(212),
% produce a plot showing 1990,1 to 1992,12
begp  = ical(1990,1,dates); % find obs # associated
endp  = ical(1992,12,dates);% with 1990,1 and 1992,12
tsplot(yt,dates,begp,endp,vnames);
% add an x-label to the bottom plot
xlabel('a sub-sample covering 1990-1992');
