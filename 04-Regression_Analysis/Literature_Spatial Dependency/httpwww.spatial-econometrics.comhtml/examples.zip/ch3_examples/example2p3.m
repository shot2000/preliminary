% ----- example 2.3
cstruct = cal(1982,1,12);
for i=1:6;
fdates{i} = tsdate(cstruct,i);
end;
fdates
