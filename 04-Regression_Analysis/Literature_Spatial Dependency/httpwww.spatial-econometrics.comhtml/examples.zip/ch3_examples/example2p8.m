% ----- example 2.8
dates = cal(1982,1,12);
load test.dat;
y = growthr(test,12);
vnames  = strvcat('IL','IN','KY','MI','OH','PA','TN','WV');    
% define beginning and ending print dates
begp = ical(1983,1,dates);
endp = ical(1984,12,dates);
tsprint(y,dates,begp,endp,vnames);
% truncate to feed initial observations
ynew = trimr(y,dates.freq,0);
% reset the calendar to reflect truncation
tdates = cal(1983,1,12);
% re-define beginning and ending print dates based on the new calendar
begp = ical(1983,1,tdates);
endp = ical(1983,12,tdates);
tsprint(ynew,tdates,begp,endp,vnames);
