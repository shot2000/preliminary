% ----- example 2.9
dates = cal(1982,1,12); % define calendar to start in 1982,1
load test.dat;
y = growthr(test,12);
y = trimr(y,12,0); 
dates = cal(1983,1,12); % re-define calendar to start in 1983,1
% try to define beginning and ending print dates
% forgetting that the calendar now starts in 1983,1
begp = ical(1982,1,dates); 
% ical will produce an error message in the above call 
