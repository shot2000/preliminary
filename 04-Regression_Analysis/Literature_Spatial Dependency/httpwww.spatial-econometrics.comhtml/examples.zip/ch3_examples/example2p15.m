% ----- example 2.15	
randn('seed',45456);
nobs = 100;
numx = 3;
b = .5 * ones(numx+1,1);
x = [ones(nobs,1) randn(nobs,numx)];
y = x * b + randn(nobs,1).^4; % 4th power for kurtotic error term 
fprintf('LS estimates = %12.6f   \n',x\y);
b_old = zeros(numx+1,1);
b_new = b;
w = x;
while max(abs(b_new - b_old)) > 1e-3;
    b_old = b_new;
    b_new = invpd(w'*x)*(w'*y);
    w = matdiv(x,abs(y - x * b_new));
end;
fprintf('LAD estimates %12.6f \n',b_new);
