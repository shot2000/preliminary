% ----- example 2.14
% Using the cal() structure
dates = cal(1982,1,12); % initialize a calendar
nobs = ical(1995,12,dates); 
dummies = sdummy(nobs,dates);
% Using an input `freq'
freq = 12;
dummies = sdummy(nobs,freq);
in.fmt = '%6.0f';
mprint(dummies,in);
