% ----- example 2.1
load test.dat; % monthly mining employment for
               % il,in,ky,mi,oh,pa,tn,wv
dates = cal(1982,1,12);          % data covers 1982,1 to 1996,5
begf = ical(1995,6,dates);       % beginning forecast period
nfor = 12;                       % number of forecast periods
datesf = cal(dates,begf+nfor-1); % add end of forecast period
begf
datesf
