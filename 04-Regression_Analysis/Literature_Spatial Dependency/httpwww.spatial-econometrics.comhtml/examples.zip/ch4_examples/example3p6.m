% ----- example 3.6
n = 100; k = 4;
x = randn(n,k); e = randn(n,1);  b = ones(k,1);
y = x*b + e;
% now add a few outliers
y(50,1) = 10.0; y(70,1) = -10.0;
vnames = strvcat('y ','x1','x2','x3','x4');
res = dfbeta(y,x);
plt_dfb(res,vnames);
pause;
plt_dff(res);
