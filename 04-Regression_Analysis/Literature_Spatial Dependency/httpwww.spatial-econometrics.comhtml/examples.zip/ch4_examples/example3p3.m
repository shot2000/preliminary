% ----- example 3.3
n = 100; k = 5;
x = randn(n,k); e = randn(n,1); b = ones(k,1);
% generate collinear data
x(:,1) = x(:,2) + x(:,4) + randn(n,1)*0.1;
y = x*b + e;
% ols regression
res = ols(y,x);
prt(res);
% ridge regression
rres = ridge(y,x);
prt(rres);
