% ----- example 3.4
n = 100; k = 5;
x = randn(n,k); e = randn(n,1); b = ones(k,1);
% generate collinear data
x(:,1) = x(:,2) + x(:,4) + randn(n,1)*0.1;
y = x*b + e;
% ridge regression
res = ridge(y,x);
theta = res.theta;
tmax = 2*theta;
ntheta = 50;
vnames = strvcat('y','x1','x2','x3','x4','x5');
rtrace(y,x,tmax,ntheta,vnames);	
