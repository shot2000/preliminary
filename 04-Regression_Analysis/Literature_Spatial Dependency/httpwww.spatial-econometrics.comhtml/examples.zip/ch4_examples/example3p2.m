% ----- example 3.2
n = 100; k = 5;
x = randn(n,k);
% generate collinear data
x(:,1) = x(:,2) + x(:,4) + randn(n,1)*0.1;
bkw(x);
