% ----- example 1.3
% copy this file to the regress directory where
% the source code for ols and prt_reg live
% before executing example1p3 in the MATLAB command window
nobs = 1000; nvar = 15;
beta = ones(nvar,1);
xmat = randn(nobs,nvar-1);
x = [ones(nobs,1) xmat];
evec = randn(nobs,1);
y = x*beta + evec;
% profile the ols function
profile ols;
result = ols(y,x); 
profile report;
% profile the prt_reg function
profile prt_reg;
prt_reg(result);
profile report;
