% ----- example 1.4
% A demonstration of using ols(),
% in a Monte Carlo (for-loop) setting
nobs = 100; nvar = 5; ntrials = 100;
beta = ones(nvar,1);       % true betas = 1
xmat = randn(nobs,nvar-1); % fixed x-matrix
x = [ones(nobs,1) xmat];   % add intercept term
bsave = zeros(ntrials,nvar); % storage for sample estimates
% generate sample y-vectors based on a fixed x-matrix and
% do ols regressions in a for-loop
for i=1:ntrials;
	evec = randn(nobs,1);
	y = x*beta + evec;
	result = ols(y,x); 	
	bsave(i,:) = result.beta'; % recover the bhat's
end;
bmean = mean(bsave); % compute the mean of bhats
bstd = std(bsave);   % compute the std deviation of bhats
fprintf(1,'Mean of the bhats \n');
	for i=1:nvar;
		fprintf(1,'%8.4f \n',bmean(1,i));
	end;
fprintf(1,'Std deviation of the bhats \n');
	for i=1:nvar;
		fprintf(1,'%8.4f \n',bstd(1,i));
	end;
% provide a histogram for each bhat
% (hist works down the columns when given a matrix argument)
hist(bsave);
ylabel('frequency of \beta outcomes');
xlabel('Estimated \beta values');
legend('\beta_1','\beta_2','\beta_3','\beta_4','\beta_5');
