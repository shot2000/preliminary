% ----- example 1.1
% demonstrate regression
load y.data;
load x.data;
result = ols(y,x);
prt(result);
plt(result);
