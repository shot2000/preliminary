% ----- example 7.4                          
% seemingly unrelated regression estimation using
% Grunfeld investment data
load grun.dat; % grunfeld investment data (page 650, Green 1997)
y1  = grun(:,1); x11 = grun(:,2); x12 = grun(:,3); % general electric
y2  = grun(:,4); x21 = grun(:,5); x22 = grun(:,6); % westinghouse
y3  = grun(:,7); x31 = grun(:,8); x32 = grun(:,9); % general motors
y4  = grun(:,10);x41 = grun(:,11);x42 = grun(:,12);% chrysler
y5  = grun(:,13);x51 = grun(:,14);x52 = grun(:,15);% us steel
nobs = length(y1); iota = ones(nobs,1);
vname1 = strvcat('I gen motors','cons','fgm','cgm');
vname2 = strvcat('I chrysler','const','fcry','ccry');
vname3 = strvcat('I gen electric','const','fge','cge'); 
vname4 = strvcat('I westinghouse','const','fwest','cwest');
vname5 = strvcat('I us steel','const','fuss','cuss');          
% set up a structure for y in each eqn
% (order follows that in Green, 1997)
y(1).eq = y3; % gm
y(2).eq = y4; % chrysler
y(3).eq = y1; % general electric
y(4).eq = y2; % westinghouse
y(5).eq = y5; % us usteel
% set up a structure for X in each eqn
X(1).eq = [iota x31 x32];
X(2).eq = [iota x41 x42];
X(3).eq = [iota x11 x12];
X(4).eq = [iota x21 x22];
X(5).eq = [iota x51 x52];
% do sur regression with iteration
neqs = 5; iflag = 1; % rely on default itmax, crit values
result = sur(neqs,y,X,iflag);
% do sur regression with no iteration
result2 = sur(neqs,y,X);
vname = strvcat(vname1,vname2,vname3,vname4,vname5);
prt(result,vname); % print results for iteration
prt(result2,vname);% print results for no iteration


