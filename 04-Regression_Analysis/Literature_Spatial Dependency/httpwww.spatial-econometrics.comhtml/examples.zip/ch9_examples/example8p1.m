% ----- example 8.1
% demo of the beta distribution functions
n = 1000; a = 10; b = 5;
tst = beta_rnd(n,a,b); % generate random draws
 % mean should equal a/(a+b)
fprintf('mean should       = %16.8f \n',a/(a+b));  
fprintf('mean of draws     = %16.8f \n',mean(tst));
% variance should equal a*b/((a+b)*(a+b)*(a+b+1))
fprintf('variance should   = %16.8f \n',(a*b)/((a+b)*(a+b)*(a+b+1)));
fprintf('variance of draws = %16.8f \n',std(tst)*std(tst));
tst = rand(n,1); tsort = sort(tst); % generate a grid of values
pdf = beta_pdf(tsort,a,b); % calculate pdf over the grid
cdf = beta_cdf(tsort,a,b); % calculate cdf over the grid
x = beta_inv(tsort,a,b);   % calculate quantiles for the grid
subplot(3,1,1),
plot(tsort,pdf); xlabel(['pdf of beta(',num2str(a),',',num2str(b),')']);
subplot(3,1,2),
plot(tsort,cdf); xlabel(['cdf of beta(',num2str(a),',',num2str(b),')']);
subplot(3,1,3), 
plot(tsort,x);   xlabel(['inv of beta(',num2str(a),',',num2str(b),')']);
