% ----- example 8.4
% compare rejection sampling with nmrt_rnd routine
tt=-3:3; m = length(tt);n = 10; 
x = zeros(n,m); x2 = zeros(n,m); time = zeros(m,2); 
for j=1:m;
% generate from -infinity to 0
% using nmrt_rnd function and keep track of time
t0 = clock;
for i=1:n; x(i,j) = nmrt_rnd(tt(j)); end;
time(j,1) = etime(clock,t0);
% generate from -infinity to 0 using rejection
%  of draws that don't meet the truncation constraint
cnt=1; 
t0 = clock;
while cnt <= n
tst = randn(1,1);
 if tst < tt(j)
 x2(cnt,j) = tst;
 cnt = cnt+1;
 end;
end;
time(j,2) = etime(clock,t0);
end;

time
