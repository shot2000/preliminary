% ----- Example 5.8 Metropolis within Gibbs sampling
n=49; ndraw = 1100; nomit = 100; nadj = ndraw-nomit;
% generate data based on a given W-matrix
load wmat.dat; W = wmat; IN = eye(n); in = ones(n,1); weig = eig(W);
lmin = 1/min(weig); lmax = 1/max(weig); % bounds on rho
rho = 0.7;    % true value of rho
y = inv(IN-rho*W)*randn(n,1); Wy = W*y;
              % set starting values
rho = 0.5;    % starting value for the sampler
sige = 10.0;  % starting value for the sampler
c = 0.5;      % for the Metropolis step (adjusted during sampling)
rsave = zeros(nadj,1); % storage for results
ssave = zeros(nadj,1);  rtmp = zeros(nomit,1);
iter = 1; cnt = 0;
while (iter <= ndraw);        % start sampling;
e = y - rho*Wy; ssr = (e'*e); % update sige;
chi = chis_rnd(1,n); sige = (ssr/chi); 
% metropolis step to get rho update
rhox = c_rho(rho,n,y,W);      % c_rho evaluates conditional
rho2 = rho + c*randn(1); accept = 0;
 while accept == 0;           % rejection bounds on rho
  if ((rho2 > lmin) & (rho2 < lmax)); accept = 1;  end;
 rho2 = rho + c*randn(1); cnt = cnt+1;
 end;                         % end of rejection for rho
rhoy = c_rho(rho2,n,y,W);     % c_rho evaluates conditional
ru = unif_rnd(1,0,1); ratio = rhoy/rhox; p = min(1,ratio);
if (ru < p)
 rho = rho2; rtmp(iter,1) = rho; iter = iter+1;
 end;
  if (iter >= nomit);
    if iter == nomit          % update c based on initial draws
    c = 2*std(rtmp(1:nomit,1));
    end;
   ssave(iter-nomit+1,1) = sige; rsave(iter-nomit+1,1) = rho;
  end; % end of if iter > nomit
end; % end of sampling loop
% printout results
fprintf(1,'hit rate =  %6.4f \n',ndraw/cnt);
fprintf(1,'mean and std of rho %6.3f %6.3f \n',mean(rsave),std(rsave));
fprintf(1,'mean and std of sig %6.3f %6.3f \n',mean(ssave),std(ssave));