% ----- do experiment to generate a table like 5.1
% ----- FAR model Gibbs sampling
n=49; ndraw = 2100; nomit = 100; nadj = ndraw-nomit;
% generate data based on a given W-matrix
load wmat.dat; W = wmat; IN = eye(n); in = ones(n,1); weig = eig(W);
cnt = 1;
time = zeros(10,2);
rsave = zeros(10,2);
accept = zeros(10,1);
rtrue = zeros(10,1);

for rho = -.9:.2:.9 % true value of rho
prior.rho = rho;    % center prior on truth
prior.rcov = 10;    % very diffuse prior
rtrue(cnt,1) = rho;
    
y = inv(IN-rho*W)*randn(n,1)*0.5; 
              % set starting values
t0 = clock;
resm = far(y,W);
time(cnt,2) = etime(clock,t0);
rsave(cnt,2) = resm.rho;
t0 = clock;
res = far_g(y,W,ndraw,nomit,prior);
time(cnt,1) = etime(clock,t0);
rsave(cnt,1) = mean(res.bdraw);
accept(cnt,1) = res.accept;
cnt = cnt+1;
end;


out = [rtrue rsave(:,1) time(:,1) accept rsave(:,2) ]

in.fmt = '%6.3f';
in.cnames = strvcat('True','Metropolis','Time','Accept','Max Like');
mprint(out,in);

