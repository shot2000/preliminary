% ----- example 5.3
n=100; k=3; % set number of observations and variables
randn('seed',10101);
x = randn(n,k); b = ones(k,1); % generate data set
randn('seed',20201);
y = x*b + randn(n,1);
ndraw = 1100; nomit = 100; % set the number of draws   
r = [1.0 1.0 1.0]'; % prior b means
T = eye(k);	        % prior b variance 
rval = 100;         % homoscedastic prior for r-value
prior.beta = r;
prior.bcov = T;
prior.rval = rval;
result = ols_g(y,x,prior,ndraw,nomit);
q = 0.025;
r = 0.01;
s = 0.95;
res = raftery(result.bdraw,q,r,s);
prt(res,vnames);	