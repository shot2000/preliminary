% ----- example 5.7
n = 200; k = 3; e = randn(n,1)*2; y = zeros(n,1);
for i=3:n
    y(i,1) = 1 + y(i-1,1)*0.25 + y(i-2,1)*0.75 + e(i,1);
end;
x = [ones(n,1) mlag(y,2)];
yt = trimr(y,100,0); xt = trimr(x,100,0); % omit first 100 for startup
vnames = strvcat('y-variable','constant','ylag1','ylag2');
res1 = ols(yt,xt);
prt(res1,vnames);
ndraw = 1100; nomit = 100;
bmean = zeros(k,1); bcov = eye(k)*100;
prior.bcov = bcov;  % diffuse prior variance
prior.beta = bmean; % prior means of zero
res2 = ar_g(yt,2,prior,ndraw,nomit);
prt(res2,'y-variable');
res3 = theil(yt,xt,bmean,eye(k),bcov);
prt(res3,vnames);
