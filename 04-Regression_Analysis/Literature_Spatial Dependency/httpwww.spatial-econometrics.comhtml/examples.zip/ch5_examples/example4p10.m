% ----- example 4.10
y = load('test.dat'); % a test data set 
vnames =  strvcat('il','in','ky','mi','oh','pa','tn','wv');         
nlag = 6;  % number of lags in var-model
sig = 0.1;
tau = 6;
theta = 0.5;
freq = 12;   % monthly data
% this is an example of using 1st-order contiguity
% of the states as weights to produce prior means
W=[0      0.5    0.5    0     0     0    0     0
   0.25   0      0.25   0.25  0.25  0    0     0
   0.20   0.20   0      0     0.20  0    0.20  0.20
   0      0.50   0      0     0.50  0    0     0
   0      0.20   0.20   0.20  0     0.20 0.20  0.20
   0      0      0      0     0.50  0    0     0.50
   0      0      1      0     0     0    0     0
   0      0      0.33   0     0.33  0.33 0     0];
% estimate the rvar model
results = rvar(y,nlag,W,freq,sig,tau,theta);
% print results to a file
fid = fopen('rvar.out','wr');
prt(results,vnames,fid);
% estimate the recm model letting the function
% determine the # of co-integrating relationships
results = recm(y,nlag,W,freq,sig,tau,theta);
% print results to a file
fid = fopen('recm.out','wr');
prt(results,vnames,fid);
