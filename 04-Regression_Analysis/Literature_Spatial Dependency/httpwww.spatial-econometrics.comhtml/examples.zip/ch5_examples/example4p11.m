% ----- example 4.11
y = load('test.dat'); % a test data set containing
               % monthly mining employment for
               % il,in,ky,mi,oh,pa,tn,wv
dates = cal(1982,1,12); % data covers 1982,1 to 1996,5
nfor = 12; % number of forecast periods
nlag = 6;  % number of lags in var-model
begf = ical(1995,1,dates);  % beginning forecast period
endf = ical(1995,12,dates); % ending forecast period
% no data transformation example
fcast1 = varf(y,nlag,nfor,begf);
% seasonal differences data transformation example
freq = 12; % set frequency of the data to monthly
fcast2 = varf(y,nlag,nfor,begf,[],freq);
% compute percentage forecast errors
actual = y(begf:endf,:);
error1 = (actual-fcast1)./actual;
error2 = (actual-fcast2)./actual;
vnames =  strvcat('il','in','ky','mi','oh','pa','tn','wv');         
fdates = cal(1995,1,12);
fprintf(1,'VAR model in levels percentage errors \n');
tsprint(error1*100,fdates,vnames,'%7.2f');
fprintf(1,'VAR - seasonally differenced data percentage errors \n');
tsprint(error2*100,fdates,vnames,'%7.2f');
