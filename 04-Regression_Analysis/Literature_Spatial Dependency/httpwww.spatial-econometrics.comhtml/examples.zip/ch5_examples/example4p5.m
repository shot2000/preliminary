% ----- example 4.5
dates = cal(1982,1,12);
load test.dat;
y = test(:,1:2); % use only two series
vnames = strvcat('illinois','indiana');
% test Illinois for I(1) status
nlags = 6;
  for i=1:nlags;
   res = adf(y(:,1),0,i);
   prt_coint(res,vnames(1,:));
  end;
% test Indiana for I(1) status
nlags = 6;
  for i=1:nlags;
   res = adf(y(:,2),0,i);
   prt(res,vnames(2,:));
  end; 
% test if Illinois and Indiana are co-integrated
  for i=1:nlags;  
  	res = cadf(y(:,1),y(:,2),0,i);
    prt(res,vnames);
  end;
