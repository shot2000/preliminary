% ----- example 4.6
vnames  = strvcat('illinos','indiana','kentucky','michigan','ohio',  ...   
           'pennsylvania','tennessee','west virginia');  
y = load('test.dat'); % use all eight states
nlag = 9;
pterm = 0;
result = johansen(y,pterm,nlag);
prt_coint(result,vnames);
