% ----- example 4.7
y = load('test.dat'); % monthly mining employment for
                      % il,in,ky,mi,oh,pa,tn,wv 1982,1 to 1996,5 
vnames =  strvcat('il','in','ky','mi','oh','pa','tn','wv');    
nlag = 2;  % number of lags in var-model
% estimate the model, letting ecm determine # of co-integrating vectors
result = ecm(y,nlag);
prt(result,vnames); % print results to the command window
