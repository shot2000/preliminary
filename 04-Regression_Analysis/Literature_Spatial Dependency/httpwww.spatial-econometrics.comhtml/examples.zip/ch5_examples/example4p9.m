% ----- example 4.9
vnames =  strvcat('il','in','ky','mi','oh','pa','tn','wv');      
dates = cal(1982,1,12);
y = load('test.dat'); % use all eight states
nlag = 2;
tight = 0.1;
decay = 1.0;

w = [1.0  1.0  1.0  0.1  0.1  0.1  0.1  0.1 
     1.0  1.0  1.0  1.0  1.0  0.1  0.1  0.1 
     1.0  1.0  1.0  0.1  1.0  0.1  1.0  1.0 
     0.1  1.0  0.1  1.0  1.0  0.1  0.1  0.1 
     0.1  1.0  1.0  1.0  1.0  1.0  0.1  1.0 
     0.1  0.1  0.1  0.1  1.0  1.0  0.1  1.0 
     0.1  0.1  1.0  0.1  0.1  0.1  1.0  0.1 
     0.1  0.1  1.0  0.1  1.0  1.0  0.1  1.0];

result = bvar(y,nlag,tight,w,decay);
prt(result,vnames);
